import type { FastifyReply, FastifyRequest } from "fastify";
import { type PrismaClient } from "../generated/prisma/client";

export class PoolController {
  constructor(private prisma: PrismaClient) {}

  /**
   * async get
   */
  public async get(request: FastifyRequest, reply: FastifyReply) {
    try {
      const data = await this.prisma.poolTables.findMany();
      return data;
    } catch (error) {
      return error;
    }
  }
 
  public async createBooking() {
      
  }
}
