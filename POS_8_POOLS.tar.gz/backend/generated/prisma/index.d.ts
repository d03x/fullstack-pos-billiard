
/**
 * Client
**/

import * as runtime from './runtime/library.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model PoolTables
 * 
 */
export type PoolTables = $Result.DefaultSelection<Prisma.$PoolTablesPayload>
/**
 * Model PoolBookings
 * 
 */
export type PoolBookings = $Result.DefaultSelection<Prisma.$PoolBookingsPayload>

/**
 * Enums
 */
export namespace $Enums {
  export const PoolTableStatus: {
  Available: 'Available',
  Occupied: 'Occupied',
  Maintenance: 'Maintenance'
};

export type PoolTableStatus = (typeof PoolTableStatus)[keyof typeof PoolTableStatus]


export const PoolTableLightStatus: {
  ON: 'ON',
  OFF: 'OFF'
};

export type PoolTableLightStatus = (typeof PoolTableLightStatus)[keyof typeof PoolTableLightStatus]


export const BookingStatus: {
  Reserved: 'Reserved',
  InProgress: 'InProgress',
  Completed: 'Completed',
  Cancelled: 'Cancelled'
};

export type BookingStatus = (typeof BookingStatus)[keyof typeof BookingStatus]

}

export type PoolTableStatus = $Enums.PoolTableStatus

export const PoolTableStatus: typeof $Enums.PoolTableStatus

export type PoolTableLightStatus = $Enums.PoolTableLightStatus

export const PoolTableLightStatus: typeof $Enums.PoolTableLightStatus

export type BookingStatus = $Enums.BookingStatus

export const BookingStatus: typeof $Enums.BookingStatus

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient()
 * // Fetch zero or more PoolTables
 * const poolTables = await prisma.poolTables.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient()
   * // Fetch zero or more PoolTables
   * const poolTables = await prisma.poolTables.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

  /**
   * Add a middleware
   * @deprecated since 4.16.0. For new code, prefer client extensions instead.
   * @see https://pris.ly/d/extensions
   */
  $use(cb: Prisma.Middleware): void

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/raw-database-access).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/concepts/components/prisma-client/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>


  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.poolTables`: Exposes CRUD operations for the **PoolTables** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PoolTables
    * const poolTables = await prisma.poolTables.findMany()
    * ```
    */
  get poolTables(): Prisma.PoolTablesDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.poolBookings`: Exposes CRUD operations for the **PoolBookings** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more PoolBookings
    * const poolBookings = await prisma.poolBookings.findMany()
    * ```
    */
  get poolBookings(): Prisma.PoolBookingsDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
   * Metrics
   */
  export type Metrics = runtime.Metrics
  export type Metric<T> = runtime.Metric<T>
  export type MetricHistogram = runtime.MetricHistogram
  export type MetricHistogramBucket = runtime.MetricHistogramBucket

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 6.11.0
   * Query Engine version: 9c30299f5a0ea26a96790e13f796dc6094db3173
   */
  export type PrismaVersion = {
    client: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    PoolTables: 'PoolTables',
    PoolBookings: 'PoolBookings'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]


  export type Datasources = {
    db?: Datasource
  }

  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "poolTables" | "poolBookings"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      PoolTables: {
        payload: Prisma.$PoolTablesPayload<ExtArgs>
        fields: Prisma.PoolTablesFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PoolTablesFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolTablesPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PoolTablesFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolTablesPayload>
          }
          findFirst: {
            args: Prisma.PoolTablesFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolTablesPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PoolTablesFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolTablesPayload>
          }
          findMany: {
            args: Prisma.PoolTablesFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolTablesPayload>[]
          }
          create: {
            args: Prisma.PoolTablesCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolTablesPayload>
          }
          createMany: {
            args: Prisma.PoolTablesCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.PoolTablesCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolTablesPayload>[]
          }
          delete: {
            args: Prisma.PoolTablesDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolTablesPayload>
          }
          update: {
            args: Prisma.PoolTablesUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolTablesPayload>
          }
          deleteMany: {
            args: Prisma.PoolTablesDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PoolTablesUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.PoolTablesUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolTablesPayload>[]
          }
          upsert: {
            args: Prisma.PoolTablesUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolTablesPayload>
          }
          aggregate: {
            args: Prisma.PoolTablesAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePoolTables>
          }
          groupBy: {
            args: Prisma.PoolTablesGroupByArgs<ExtArgs>
            result: $Utils.Optional<PoolTablesGroupByOutputType>[]
          }
          count: {
            args: Prisma.PoolTablesCountArgs<ExtArgs>
            result: $Utils.Optional<PoolTablesCountAggregateOutputType> | number
          }
        }
      }
      PoolBookings: {
        payload: Prisma.$PoolBookingsPayload<ExtArgs>
        fields: Prisma.PoolBookingsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PoolBookingsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolBookingsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PoolBookingsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolBookingsPayload>
          }
          findFirst: {
            args: Prisma.PoolBookingsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolBookingsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PoolBookingsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolBookingsPayload>
          }
          findMany: {
            args: Prisma.PoolBookingsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolBookingsPayload>[]
          }
          create: {
            args: Prisma.PoolBookingsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolBookingsPayload>
          }
          createMany: {
            args: Prisma.PoolBookingsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.PoolBookingsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolBookingsPayload>[]
          }
          delete: {
            args: Prisma.PoolBookingsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolBookingsPayload>
          }
          update: {
            args: Prisma.PoolBookingsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolBookingsPayload>
          }
          deleteMany: {
            args: Prisma.PoolBookingsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PoolBookingsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.PoolBookingsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolBookingsPayload>[]
          }
          upsert: {
            args: Prisma.PoolBookingsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PoolBookingsPayload>
          }
          aggregate: {
            args: Prisma.PoolBookingsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePoolBookings>
          }
          groupBy: {
            args: Prisma.PoolBookingsGroupByArgs<ExtArgs>
            result: $Utils.Optional<PoolBookingsGroupByOutputType>[]
          }
          count: {
            args: Prisma.PoolBookingsCountArgs<ExtArgs>
            result: $Utils.Optional<PoolBookingsCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasources?: Datasources
    /**
     * Overwrites the datasource url from your schema.prisma file
     */
    datasourceUrl?: string
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Defaults to stdout
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events
     * log: [
     *   { emit: 'stdout', level: 'query' },
     *   { emit: 'stdout', level: 'info' },
     *   { emit: 'stdout', level: 'warn' }
     *   { emit: 'stdout', level: 'error' }
     * ]
     * ```
     * Read more in our [docs](https://www.prisma.io/docs/reference/tools-and-interfaces/prisma-client/logging#the-log-option).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
  }
  export type GlobalOmitConfig = {
    poolTables?: PoolTablesOmit
    poolBookings?: PoolBookingsOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type GetLogType<T extends LogLevel | LogDefinition> = T extends LogDefinition ? T['emit'] extends 'event' ? T['level'] : never : never
  export type GetEvents<T extends any> = T extends Array<LogLevel | LogDefinition> ?
    GetLogType<T[0]> | GetLogType<T[1]> | GetLogType<T[2]> | GetLogType<T[3]>
    : never

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  /**
   * These options are being passed into the middleware as "params"
   */
  export type MiddlewareParams = {
    model?: ModelName
    action: PrismaAction
    args: any
    dataPath: string[]
    runInTransaction: boolean
  }

  /**
   * The `T` type makes sure, that the `return proceed` is not forgotten in the middleware implementation
   */
  export type Middleware<T = any> = (
    params: MiddlewareParams,
    next: (params: MiddlewareParams) => $Utils.JsPromise<T>,
  ) => $Utils.JsPromise<T>

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type PoolTablesCountOutputType
   */

  export type PoolTablesCountOutputType = {
    PoolBookings: number
  }

  export type PoolTablesCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    PoolBookings?: boolean | PoolTablesCountOutputTypeCountPoolBookingsArgs
  }

  // Custom InputTypes
  /**
   * PoolTablesCountOutputType without action
   */
  export type PoolTablesCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolTablesCountOutputType
     */
    select?: PoolTablesCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * PoolTablesCountOutputType without action
   */
  export type PoolTablesCountOutputTypeCountPoolBookingsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PoolBookingsWhereInput
  }


  /**
   * Models
   */

  /**
   * Model PoolTables
   */

  export type AggregatePoolTables = {
    _count: PoolTablesCountAggregateOutputType | null
    _avg: PoolTablesAvgAggregateOutputType | null
    _sum: PoolTablesSumAggregateOutputType | null
    _min: PoolTablesMinAggregateOutputType | null
    _max: PoolTablesMaxAggregateOutputType | null
  }

  export type PoolTablesAvgAggregateOutputType = {
    id: number | null
    hourly_rate: Decimal | null
  }

  export type PoolTablesSumAggregateOutputType = {
    id: number | null
    hourly_rate: Decimal | null
  }

  export type PoolTablesMinAggregateOutputType = {
    id: number | null
    name: string | null
    light_pin: string | null
    light_status: $Enums.PoolTableLightStatus | null
    hourly_rate: Decimal | null
    status: $Enums.PoolTableStatus | null
  }

  export type PoolTablesMaxAggregateOutputType = {
    id: number | null
    name: string | null
    light_pin: string | null
    light_status: $Enums.PoolTableLightStatus | null
    hourly_rate: Decimal | null
    status: $Enums.PoolTableStatus | null
  }

  export type PoolTablesCountAggregateOutputType = {
    id: number
    name: number
    light_pin: number
    light_status: number
    hourly_rate: number
    status: number
    _all: number
  }


  export type PoolTablesAvgAggregateInputType = {
    id?: true
    hourly_rate?: true
  }

  export type PoolTablesSumAggregateInputType = {
    id?: true
    hourly_rate?: true
  }

  export type PoolTablesMinAggregateInputType = {
    id?: true
    name?: true
    light_pin?: true
    light_status?: true
    hourly_rate?: true
    status?: true
  }

  export type PoolTablesMaxAggregateInputType = {
    id?: true
    name?: true
    light_pin?: true
    light_status?: true
    hourly_rate?: true
    status?: true
  }

  export type PoolTablesCountAggregateInputType = {
    id?: true
    name?: true
    light_pin?: true
    light_status?: true
    hourly_rate?: true
    status?: true
    _all?: true
  }

  export type PoolTablesAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PoolTables to aggregate.
     */
    where?: PoolTablesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PoolTables to fetch.
     */
    orderBy?: PoolTablesOrderByWithRelationInput | PoolTablesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PoolTablesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PoolTables from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PoolTables.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PoolTables
    **/
    _count?: true | PoolTablesCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PoolTablesAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PoolTablesSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PoolTablesMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PoolTablesMaxAggregateInputType
  }

  export type GetPoolTablesAggregateType<T extends PoolTablesAggregateArgs> = {
        [P in keyof T & keyof AggregatePoolTables]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePoolTables[P]>
      : GetScalarType<T[P], AggregatePoolTables[P]>
  }




  export type PoolTablesGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PoolTablesWhereInput
    orderBy?: PoolTablesOrderByWithAggregationInput | PoolTablesOrderByWithAggregationInput[]
    by: PoolTablesScalarFieldEnum[] | PoolTablesScalarFieldEnum
    having?: PoolTablesScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PoolTablesCountAggregateInputType | true
    _avg?: PoolTablesAvgAggregateInputType
    _sum?: PoolTablesSumAggregateInputType
    _min?: PoolTablesMinAggregateInputType
    _max?: PoolTablesMaxAggregateInputType
  }

  export type PoolTablesGroupByOutputType = {
    id: number
    name: string
    light_pin: string
    light_status: $Enums.PoolTableLightStatus
    hourly_rate: Decimal
    status: $Enums.PoolTableStatus
    _count: PoolTablesCountAggregateOutputType | null
    _avg: PoolTablesAvgAggregateOutputType | null
    _sum: PoolTablesSumAggregateOutputType | null
    _min: PoolTablesMinAggregateOutputType | null
    _max: PoolTablesMaxAggregateOutputType | null
  }

  type GetPoolTablesGroupByPayload<T extends PoolTablesGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PoolTablesGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PoolTablesGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PoolTablesGroupByOutputType[P]>
            : GetScalarType<T[P], PoolTablesGroupByOutputType[P]>
        }
      >
    >


  export type PoolTablesSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    light_pin?: boolean
    light_status?: boolean
    hourly_rate?: boolean
    status?: boolean
    PoolBookings?: boolean | PoolTables$PoolBookingsArgs<ExtArgs>
    _count?: boolean | PoolTablesCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["poolTables"]>

  export type PoolTablesSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    light_pin?: boolean
    light_status?: boolean
    hourly_rate?: boolean
    status?: boolean
  }, ExtArgs["result"]["poolTables"]>

  export type PoolTablesSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    name?: boolean
    light_pin?: boolean
    light_status?: boolean
    hourly_rate?: boolean
    status?: boolean
  }, ExtArgs["result"]["poolTables"]>

  export type PoolTablesSelectScalar = {
    id?: boolean
    name?: boolean
    light_pin?: boolean
    light_status?: boolean
    hourly_rate?: boolean
    status?: boolean
  }

  export type PoolTablesOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "name" | "light_pin" | "light_status" | "hourly_rate" | "status", ExtArgs["result"]["poolTables"]>
  export type PoolTablesInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    PoolBookings?: boolean | PoolTables$PoolBookingsArgs<ExtArgs>
    _count?: boolean | PoolTablesCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type PoolTablesIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type PoolTablesIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $PoolTablesPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PoolTables"
    objects: {
      PoolBookings: Prisma.$PoolBookingsPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      name: string
      light_pin: string
      light_status: $Enums.PoolTableLightStatus
      hourly_rate: Prisma.Decimal
      status: $Enums.PoolTableStatus
    }, ExtArgs["result"]["poolTables"]>
    composites: {}
  }

  type PoolTablesGetPayload<S extends boolean | null | undefined | PoolTablesDefaultArgs> = $Result.GetResult<Prisma.$PoolTablesPayload, S>

  type PoolTablesCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PoolTablesFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PoolTablesCountAggregateInputType | true
    }

  export interface PoolTablesDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PoolTables'], meta: { name: 'PoolTables' } }
    /**
     * Find zero or one PoolTables that matches the filter.
     * @param {PoolTablesFindUniqueArgs} args - Arguments to find a PoolTables
     * @example
     * // Get one PoolTables
     * const poolTables = await prisma.poolTables.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PoolTablesFindUniqueArgs>(args: SelectSubset<T, PoolTablesFindUniqueArgs<ExtArgs>>): Prisma__PoolTablesClient<$Result.GetResult<Prisma.$PoolTablesPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PoolTables that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PoolTablesFindUniqueOrThrowArgs} args - Arguments to find a PoolTables
     * @example
     * // Get one PoolTables
     * const poolTables = await prisma.poolTables.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PoolTablesFindUniqueOrThrowArgs>(args: SelectSubset<T, PoolTablesFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PoolTablesClient<$Result.GetResult<Prisma.$PoolTablesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PoolTables that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolTablesFindFirstArgs} args - Arguments to find a PoolTables
     * @example
     * // Get one PoolTables
     * const poolTables = await prisma.poolTables.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PoolTablesFindFirstArgs>(args?: SelectSubset<T, PoolTablesFindFirstArgs<ExtArgs>>): Prisma__PoolTablesClient<$Result.GetResult<Prisma.$PoolTablesPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PoolTables that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolTablesFindFirstOrThrowArgs} args - Arguments to find a PoolTables
     * @example
     * // Get one PoolTables
     * const poolTables = await prisma.poolTables.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PoolTablesFindFirstOrThrowArgs>(args?: SelectSubset<T, PoolTablesFindFirstOrThrowArgs<ExtArgs>>): Prisma__PoolTablesClient<$Result.GetResult<Prisma.$PoolTablesPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PoolTables that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolTablesFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PoolTables
     * const poolTables = await prisma.poolTables.findMany()
     * 
     * // Get first 10 PoolTables
     * const poolTables = await prisma.poolTables.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const poolTablesWithIdOnly = await prisma.poolTables.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PoolTablesFindManyArgs>(args?: SelectSubset<T, PoolTablesFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PoolTablesPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PoolTables.
     * @param {PoolTablesCreateArgs} args - Arguments to create a PoolTables.
     * @example
     * // Create one PoolTables
     * const PoolTables = await prisma.poolTables.create({
     *   data: {
     *     // ... data to create a PoolTables
     *   }
     * })
     * 
     */
    create<T extends PoolTablesCreateArgs>(args: SelectSubset<T, PoolTablesCreateArgs<ExtArgs>>): Prisma__PoolTablesClient<$Result.GetResult<Prisma.$PoolTablesPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PoolTables.
     * @param {PoolTablesCreateManyArgs} args - Arguments to create many PoolTables.
     * @example
     * // Create many PoolTables
     * const poolTables = await prisma.poolTables.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PoolTablesCreateManyArgs>(args?: SelectSubset<T, PoolTablesCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many PoolTables and returns the data saved in the database.
     * @param {PoolTablesCreateManyAndReturnArgs} args - Arguments to create many PoolTables.
     * @example
     * // Create many PoolTables
     * const poolTables = await prisma.poolTables.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many PoolTables and only return the `id`
     * const poolTablesWithIdOnly = await prisma.poolTables.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends PoolTablesCreateManyAndReturnArgs>(args?: SelectSubset<T, PoolTablesCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PoolTablesPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a PoolTables.
     * @param {PoolTablesDeleteArgs} args - Arguments to delete one PoolTables.
     * @example
     * // Delete one PoolTables
     * const PoolTables = await prisma.poolTables.delete({
     *   where: {
     *     // ... filter to delete one PoolTables
     *   }
     * })
     * 
     */
    delete<T extends PoolTablesDeleteArgs>(args: SelectSubset<T, PoolTablesDeleteArgs<ExtArgs>>): Prisma__PoolTablesClient<$Result.GetResult<Prisma.$PoolTablesPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PoolTables.
     * @param {PoolTablesUpdateArgs} args - Arguments to update one PoolTables.
     * @example
     * // Update one PoolTables
     * const poolTables = await prisma.poolTables.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PoolTablesUpdateArgs>(args: SelectSubset<T, PoolTablesUpdateArgs<ExtArgs>>): Prisma__PoolTablesClient<$Result.GetResult<Prisma.$PoolTablesPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PoolTables.
     * @param {PoolTablesDeleteManyArgs} args - Arguments to filter PoolTables to delete.
     * @example
     * // Delete a few PoolTables
     * const { count } = await prisma.poolTables.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PoolTablesDeleteManyArgs>(args?: SelectSubset<T, PoolTablesDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PoolTables.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolTablesUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PoolTables
     * const poolTables = await prisma.poolTables.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PoolTablesUpdateManyArgs>(args: SelectSubset<T, PoolTablesUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PoolTables and returns the data updated in the database.
     * @param {PoolTablesUpdateManyAndReturnArgs} args - Arguments to update many PoolTables.
     * @example
     * // Update many PoolTables
     * const poolTables = await prisma.poolTables.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more PoolTables and only return the `id`
     * const poolTablesWithIdOnly = await prisma.poolTables.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends PoolTablesUpdateManyAndReturnArgs>(args: SelectSubset<T, PoolTablesUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PoolTablesPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one PoolTables.
     * @param {PoolTablesUpsertArgs} args - Arguments to update or create a PoolTables.
     * @example
     * // Update or create a PoolTables
     * const poolTables = await prisma.poolTables.upsert({
     *   create: {
     *     // ... data to create a PoolTables
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PoolTables we want to update
     *   }
     * })
     */
    upsert<T extends PoolTablesUpsertArgs>(args: SelectSubset<T, PoolTablesUpsertArgs<ExtArgs>>): Prisma__PoolTablesClient<$Result.GetResult<Prisma.$PoolTablesPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PoolTables.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolTablesCountArgs} args - Arguments to filter PoolTables to count.
     * @example
     * // Count the number of PoolTables
     * const count = await prisma.poolTables.count({
     *   where: {
     *     // ... the filter for the PoolTables we want to count
     *   }
     * })
    **/
    count<T extends PoolTablesCountArgs>(
      args?: Subset<T, PoolTablesCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PoolTablesCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PoolTables.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolTablesAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PoolTablesAggregateArgs>(args: Subset<T, PoolTablesAggregateArgs>): Prisma.PrismaPromise<GetPoolTablesAggregateType<T>>

    /**
     * Group by PoolTables.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolTablesGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PoolTablesGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PoolTablesGroupByArgs['orderBy'] }
        : { orderBy?: PoolTablesGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PoolTablesGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPoolTablesGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PoolTables model
   */
  readonly fields: PoolTablesFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PoolTables.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PoolTablesClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    PoolBookings<T extends PoolTables$PoolBookingsArgs<ExtArgs> = {}>(args?: Subset<T, PoolTables$PoolBookingsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PoolBookingsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PoolTables model
   */
  interface PoolTablesFieldRefs {
    readonly id: FieldRef<"PoolTables", 'Int'>
    readonly name: FieldRef<"PoolTables", 'String'>
    readonly light_pin: FieldRef<"PoolTables", 'String'>
    readonly light_status: FieldRef<"PoolTables", 'PoolTableLightStatus'>
    readonly hourly_rate: FieldRef<"PoolTables", 'Decimal'>
    readonly status: FieldRef<"PoolTables", 'PoolTableStatus'>
  }
    

  // Custom InputTypes
  /**
   * PoolTables findUnique
   */
  export type PoolTablesFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolTables
     */
    select?: PoolTablesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolTables
     */
    omit?: PoolTablesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolTablesInclude<ExtArgs> | null
    /**
     * Filter, which PoolTables to fetch.
     */
    where: PoolTablesWhereUniqueInput
  }

  /**
   * PoolTables findUniqueOrThrow
   */
  export type PoolTablesFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolTables
     */
    select?: PoolTablesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolTables
     */
    omit?: PoolTablesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolTablesInclude<ExtArgs> | null
    /**
     * Filter, which PoolTables to fetch.
     */
    where: PoolTablesWhereUniqueInput
  }

  /**
   * PoolTables findFirst
   */
  export type PoolTablesFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolTables
     */
    select?: PoolTablesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolTables
     */
    omit?: PoolTablesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolTablesInclude<ExtArgs> | null
    /**
     * Filter, which PoolTables to fetch.
     */
    where?: PoolTablesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PoolTables to fetch.
     */
    orderBy?: PoolTablesOrderByWithRelationInput | PoolTablesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PoolTables.
     */
    cursor?: PoolTablesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PoolTables from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PoolTables.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PoolTables.
     */
    distinct?: PoolTablesScalarFieldEnum | PoolTablesScalarFieldEnum[]
  }

  /**
   * PoolTables findFirstOrThrow
   */
  export type PoolTablesFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolTables
     */
    select?: PoolTablesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolTables
     */
    omit?: PoolTablesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolTablesInclude<ExtArgs> | null
    /**
     * Filter, which PoolTables to fetch.
     */
    where?: PoolTablesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PoolTables to fetch.
     */
    orderBy?: PoolTablesOrderByWithRelationInput | PoolTablesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PoolTables.
     */
    cursor?: PoolTablesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PoolTables from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PoolTables.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PoolTables.
     */
    distinct?: PoolTablesScalarFieldEnum | PoolTablesScalarFieldEnum[]
  }

  /**
   * PoolTables findMany
   */
  export type PoolTablesFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolTables
     */
    select?: PoolTablesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolTables
     */
    omit?: PoolTablesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolTablesInclude<ExtArgs> | null
    /**
     * Filter, which PoolTables to fetch.
     */
    where?: PoolTablesWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PoolTables to fetch.
     */
    orderBy?: PoolTablesOrderByWithRelationInput | PoolTablesOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PoolTables.
     */
    cursor?: PoolTablesWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PoolTables from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PoolTables.
     */
    skip?: number
    distinct?: PoolTablesScalarFieldEnum | PoolTablesScalarFieldEnum[]
  }

  /**
   * PoolTables create
   */
  export type PoolTablesCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolTables
     */
    select?: PoolTablesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolTables
     */
    omit?: PoolTablesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolTablesInclude<ExtArgs> | null
    /**
     * The data needed to create a PoolTables.
     */
    data: XOR<PoolTablesCreateInput, PoolTablesUncheckedCreateInput>
  }

  /**
   * PoolTables createMany
   */
  export type PoolTablesCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PoolTables.
     */
    data: PoolTablesCreateManyInput | PoolTablesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PoolTables createManyAndReturn
   */
  export type PoolTablesCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolTables
     */
    select?: PoolTablesSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PoolTables
     */
    omit?: PoolTablesOmit<ExtArgs> | null
    /**
     * The data used to create many PoolTables.
     */
    data: PoolTablesCreateManyInput | PoolTablesCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PoolTables update
   */
  export type PoolTablesUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolTables
     */
    select?: PoolTablesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolTables
     */
    omit?: PoolTablesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolTablesInclude<ExtArgs> | null
    /**
     * The data needed to update a PoolTables.
     */
    data: XOR<PoolTablesUpdateInput, PoolTablesUncheckedUpdateInput>
    /**
     * Choose, which PoolTables to update.
     */
    where: PoolTablesWhereUniqueInput
  }

  /**
   * PoolTables updateMany
   */
  export type PoolTablesUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PoolTables.
     */
    data: XOR<PoolTablesUpdateManyMutationInput, PoolTablesUncheckedUpdateManyInput>
    /**
     * Filter which PoolTables to update
     */
    where?: PoolTablesWhereInput
    /**
     * Limit how many PoolTables to update.
     */
    limit?: number
  }

  /**
   * PoolTables updateManyAndReturn
   */
  export type PoolTablesUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolTables
     */
    select?: PoolTablesSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PoolTables
     */
    omit?: PoolTablesOmit<ExtArgs> | null
    /**
     * The data used to update PoolTables.
     */
    data: XOR<PoolTablesUpdateManyMutationInput, PoolTablesUncheckedUpdateManyInput>
    /**
     * Filter which PoolTables to update
     */
    where?: PoolTablesWhereInput
    /**
     * Limit how many PoolTables to update.
     */
    limit?: number
  }

  /**
   * PoolTables upsert
   */
  export type PoolTablesUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolTables
     */
    select?: PoolTablesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolTables
     */
    omit?: PoolTablesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolTablesInclude<ExtArgs> | null
    /**
     * The filter to search for the PoolTables to update in case it exists.
     */
    where: PoolTablesWhereUniqueInput
    /**
     * In case the PoolTables found by the `where` argument doesn't exist, create a new PoolTables with this data.
     */
    create: XOR<PoolTablesCreateInput, PoolTablesUncheckedCreateInput>
    /**
     * In case the PoolTables was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PoolTablesUpdateInput, PoolTablesUncheckedUpdateInput>
  }

  /**
   * PoolTables delete
   */
  export type PoolTablesDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolTables
     */
    select?: PoolTablesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolTables
     */
    omit?: PoolTablesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolTablesInclude<ExtArgs> | null
    /**
     * Filter which PoolTables to delete.
     */
    where: PoolTablesWhereUniqueInput
  }

  /**
   * PoolTables deleteMany
   */
  export type PoolTablesDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PoolTables to delete
     */
    where?: PoolTablesWhereInput
    /**
     * Limit how many PoolTables to delete.
     */
    limit?: number
  }

  /**
   * PoolTables.PoolBookings
   */
  export type PoolTables$PoolBookingsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolBookings
     */
    select?: PoolBookingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolBookings
     */
    omit?: PoolBookingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolBookingsInclude<ExtArgs> | null
    where?: PoolBookingsWhereInput
    orderBy?: PoolBookingsOrderByWithRelationInput | PoolBookingsOrderByWithRelationInput[]
    cursor?: PoolBookingsWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PoolBookingsScalarFieldEnum | PoolBookingsScalarFieldEnum[]
  }

  /**
   * PoolTables without action
   */
  export type PoolTablesDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolTables
     */
    select?: PoolTablesSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolTables
     */
    omit?: PoolTablesOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolTablesInclude<ExtArgs> | null
  }


  /**
   * Model PoolBookings
   */

  export type AggregatePoolBookings = {
    _count: PoolBookingsCountAggregateOutputType | null
    _avg: PoolBookingsAvgAggregateOutputType | null
    _sum: PoolBookingsSumAggregateOutputType | null
    _min: PoolBookingsMinAggregateOutputType | null
    _max: PoolBookingsMaxAggregateOutputType | null
  }

  export type PoolBookingsAvgAggregateOutputType = {
    id: number | null
    tableId: number | null
    durationHours: number | null
    hourlyRate: number | null
    totalPrice: number | null
  }

  export type PoolBookingsSumAggregateOutputType = {
    id: number | null
    tableId: number | null
    durationHours: number | null
    hourlyRate: number | null
    totalPrice: number | null
  }

  export type PoolBookingsMinAggregateOutputType = {
    id: number | null
    customer_name: string | null
    tableId: number | null
    startTime: Date | null
    endTime: Date | null
    durationHours: number | null
    hourlyRate: number | null
    totalPrice: number | null
    status: $Enums.BookingStatus | null
    initialLightStatus: string | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type PoolBookingsMaxAggregateOutputType = {
    id: number | null
    customer_name: string | null
    tableId: number | null
    startTime: Date | null
    endTime: Date | null
    durationHours: number | null
    hourlyRate: number | null
    totalPrice: number | null
    status: $Enums.BookingStatus | null
    initialLightStatus: string | null
    notes: string | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type PoolBookingsCountAggregateOutputType = {
    id: number
    customer_name: number
    tableId: number
    startTime: number
    endTime: number
    durationHours: number
    hourlyRate: number
    totalPrice: number
    status: number
    initialLightStatus: number
    notes: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type PoolBookingsAvgAggregateInputType = {
    id?: true
    tableId?: true
    durationHours?: true
    hourlyRate?: true
    totalPrice?: true
  }

  export type PoolBookingsSumAggregateInputType = {
    id?: true
    tableId?: true
    durationHours?: true
    hourlyRate?: true
    totalPrice?: true
  }

  export type PoolBookingsMinAggregateInputType = {
    id?: true
    customer_name?: true
    tableId?: true
    startTime?: true
    endTime?: true
    durationHours?: true
    hourlyRate?: true
    totalPrice?: true
    status?: true
    initialLightStatus?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
  }

  export type PoolBookingsMaxAggregateInputType = {
    id?: true
    customer_name?: true
    tableId?: true
    startTime?: true
    endTime?: true
    durationHours?: true
    hourlyRate?: true
    totalPrice?: true
    status?: true
    initialLightStatus?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
  }

  export type PoolBookingsCountAggregateInputType = {
    id?: true
    customer_name?: true
    tableId?: true
    startTime?: true
    endTime?: true
    durationHours?: true
    hourlyRate?: true
    totalPrice?: true
    status?: true
    initialLightStatus?: true
    notes?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type PoolBookingsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PoolBookings to aggregate.
     */
    where?: PoolBookingsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PoolBookings to fetch.
     */
    orderBy?: PoolBookingsOrderByWithRelationInput | PoolBookingsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PoolBookingsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PoolBookings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PoolBookings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned PoolBookings
    **/
    _count?: true | PoolBookingsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PoolBookingsAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PoolBookingsSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PoolBookingsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PoolBookingsMaxAggregateInputType
  }

  export type GetPoolBookingsAggregateType<T extends PoolBookingsAggregateArgs> = {
        [P in keyof T & keyof AggregatePoolBookings]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePoolBookings[P]>
      : GetScalarType<T[P], AggregatePoolBookings[P]>
  }




  export type PoolBookingsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PoolBookingsWhereInput
    orderBy?: PoolBookingsOrderByWithAggregationInput | PoolBookingsOrderByWithAggregationInput[]
    by: PoolBookingsScalarFieldEnum[] | PoolBookingsScalarFieldEnum
    having?: PoolBookingsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PoolBookingsCountAggregateInputType | true
    _avg?: PoolBookingsAvgAggregateInputType
    _sum?: PoolBookingsSumAggregateInputType
    _min?: PoolBookingsMinAggregateInputType
    _max?: PoolBookingsMaxAggregateInputType
  }

  export type PoolBookingsGroupByOutputType = {
    id: number
    customer_name: string | null
    tableId: number
    startTime: Date
    endTime: Date | null
    durationHours: number | null
    hourlyRate: number
    totalPrice: number | null
    status: $Enums.BookingStatus
    initialLightStatus: string | null
    notes: string | null
    createdAt: Date
    updatedAt: Date
    _count: PoolBookingsCountAggregateOutputType | null
    _avg: PoolBookingsAvgAggregateOutputType | null
    _sum: PoolBookingsSumAggregateOutputType | null
    _min: PoolBookingsMinAggregateOutputType | null
    _max: PoolBookingsMaxAggregateOutputType | null
  }

  type GetPoolBookingsGroupByPayload<T extends PoolBookingsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PoolBookingsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PoolBookingsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PoolBookingsGroupByOutputType[P]>
            : GetScalarType<T[P], PoolBookingsGroupByOutputType[P]>
        }
      >
    >


  export type PoolBookingsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    customer_name?: boolean
    tableId?: boolean
    startTime?: boolean
    endTime?: boolean
    durationHours?: boolean
    hourlyRate?: boolean
    totalPrice?: boolean
    status?: boolean
    initialLightStatus?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    poolTable?: boolean | PoolTablesDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["poolBookings"]>

  export type PoolBookingsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    customer_name?: boolean
    tableId?: boolean
    startTime?: boolean
    endTime?: boolean
    durationHours?: boolean
    hourlyRate?: boolean
    totalPrice?: boolean
    status?: boolean
    initialLightStatus?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    poolTable?: boolean | PoolTablesDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["poolBookings"]>

  export type PoolBookingsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    customer_name?: boolean
    tableId?: boolean
    startTime?: boolean
    endTime?: boolean
    durationHours?: boolean
    hourlyRate?: boolean
    totalPrice?: boolean
    status?: boolean
    initialLightStatus?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    poolTable?: boolean | PoolTablesDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["poolBookings"]>

  export type PoolBookingsSelectScalar = {
    id?: boolean
    customer_name?: boolean
    tableId?: boolean
    startTime?: boolean
    endTime?: boolean
    durationHours?: boolean
    hourlyRate?: boolean
    totalPrice?: boolean
    status?: boolean
    initialLightStatus?: boolean
    notes?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type PoolBookingsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "customer_name" | "tableId" | "startTime" | "endTime" | "durationHours" | "hourlyRate" | "totalPrice" | "status" | "initialLightStatus" | "notes" | "createdAt" | "updatedAt", ExtArgs["result"]["poolBookings"]>
  export type PoolBookingsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    poolTable?: boolean | PoolTablesDefaultArgs<ExtArgs>
  }
  export type PoolBookingsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    poolTable?: boolean | PoolTablesDefaultArgs<ExtArgs>
  }
  export type PoolBookingsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    poolTable?: boolean | PoolTablesDefaultArgs<ExtArgs>
  }

  export type $PoolBookingsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "PoolBookings"
    objects: {
      poolTable: Prisma.$PoolTablesPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: number
      customer_name: string | null
      tableId: number
      startTime: Date
      endTime: Date | null
      durationHours: number | null
      hourlyRate: number
      totalPrice: number | null
      status: $Enums.BookingStatus
      initialLightStatus: string | null
      notes: string | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["poolBookings"]>
    composites: {}
  }

  type PoolBookingsGetPayload<S extends boolean | null | undefined | PoolBookingsDefaultArgs> = $Result.GetResult<Prisma.$PoolBookingsPayload, S>

  type PoolBookingsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PoolBookingsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PoolBookingsCountAggregateInputType | true
    }

  export interface PoolBookingsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['PoolBookings'], meta: { name: 'PoolBookings' } }
    /**
     * Find zero or one PoolBookings that matches the filter.
     * @param {PoolBookingsFindUniqueArgs} args - Arguments to find a PoolBookings
     * @example
     * // Get one PoolBookings
     * const poolBookings = await prisma.poolBookings.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PoolBookingsFindUniqueArgs>(args: SelectSubset<T, PoolBookingsFindUniqueArgs<ExtArgs>>): Prisma__PoolBookingsClient<$Result.GetResult<Prisma.$PoolBookingsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one PoolBookings that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PoolBookingsFindUniqueOrThrowArgs} args - Arguments to find a PoolBookings
     * @example
     * // Get one PoolBookings
     * const poolBookings = await prisma.poolBookings.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PoolBookingsFindUniqueOrThrowArgs>(args: SelectSubset<T, PoolBookingsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PoolBookingsClient<$Result.GetResult<Prisma.$PoolBookingsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PoolBookings that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolBookingsFindFirstArgs} args - Arguments to find a PoolBookings
     * @example
     * // Get one PoolBookings
     * const poolBookings = await prisma.poolBookings.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PoolBookingsFindFirstArgs>(args?: SelectSubset<T, PoolBookingsFindFirstArgs<ExtArgs>>): Prisma__PoolBookingsClient<$Result.GetResult<Prisma.$PoolBookingsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first PoolBookings that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolBookingsFindFirstOrThrowArgs} args - Arguments to find a PoolBookings
     * @example
     * // Get one PoolBookings
     * const poolBookings = await prisma.poolBookings.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PoolBookingsFindFirstOrThrowArgs>(args?: SelectSubset<T, PoolBookingsFindFirstOrThrowArgs<ExtArgs>>): Prisma__PoolBookingsClient<$Result.GetResult<Prisma.$PoolBookingsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more PoolBookings that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolBookingsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all PoolBookings
     * const poolBookings = await prisma.poolBookings.findMany()
     * 
     * // Get first 10 PoolBookings
     * const poolBookings = await prisma.poolBookings.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const poolBookingsWithIdOnly = await prisma.poolBookings.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PoolBookingsFindManyArgs>(args?: SelectSubset<T, PoolBookingsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PoolBookingsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a PoolBookings.
     * @param {PoolBookingsCreateArgs} args - Arguments to create a PoolBookings.
     * @example
     * // Create one PoolBookings
     * const PoolBookings = await prisma.poolBookings.create({
     *   data: {
     *     // ... data to create a PoolBookings
     *   }
     * })
     * 
     */
    create<T extends PoolBookingsCreateArgs>(args: SelectSubset<T, PoolBookingsCreateArgs<ExtArgs>>): Prisma__PoolBookingsClient<$Result.GetResult<Prisma.$PoolBookingsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many PoolBookings.
     * @param {PoolBookingsCreateManyArgs} args - Arguments to create many PoolBookings.
     * @example
     * // Create many PoolBookings
     * const poolBookings = await prisma.poolBookings.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PoolBookingsCreateManyArgs>(args?: SelectSubset<T, PoolBookingsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many PoolBookings and returns the data saved in the database.
     * @param {PoolBookingsCreateManyAndReturnArgs} args - Arguments to create many PoolBookings.
     * @example
     * // Create many PoolBookings
     * const poolBookings = await prisma.poolBookings.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many PoolBookings and only return the `id`
     * const poolBookingsWithIdOnly = await prisma.poolBookings.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends PoolBookingsCreateManyAndReturnArgs>(args?: SelectSubset<T, PoolBookingsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PoolBookingsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a PoolBookings.
     * @param {PoolBookingsDeleteArgs} args - Arguments to delete one PoolBookings.
     * @example
     * // Delete one PoolBookings
     * const PoolBookings = await prisma.poolBookings.delete({
     *   where: {
     *     // ... filter to delete one PoolBookings
     *   }
     * })
     * 
     */
    delete<T extends PoolBookingsDeleteArgs>(args: SelectSubset<T, PoolBookingsDeleteArgs<ExtArgs>>): Prisma__PoolBookingsClient<$Result.GetResult<Prisma.$PoolBookingsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one PoolBookings.
     * @param {PoolBookingsUpdateArgs} args - Arguments to update one PoolBookings.
     * @example
     * // Update one PoolBookings
     * const poolBookings = await prisma.poolBookings.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PoolBookingsUpdateArgs>(args: SelectSubset<T, PoolBookingsUpdateArgs<ExtArgs>>): Prisma__PoolBookingsClient<$Result.GetResult<Prisma.$PoolBookingsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more PoolBookings.
     * @param {PoolBookingsDeleteManyArgs} args - Arguments to filter PoolBookings to delete.
     * @example
     * // Delete a few PoolBookings
     * const { count } = await prisma.poolBookings.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PoolBookingsDeleteManyArgs>(args?: SelectSubset<T, PoolBookingsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PoolBookings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolBookingsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many PoolBookings
     * const poolBookings = await prisma.poolBookings.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PoolBookingsUpdateManyArgs>(args: SelectSubset<T, PoolBookingsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more PoolBookings and returns the data updated in the database.
     * @param {PoolBookingsUpdateManyAndReturnArgs} args - Arguments to update many PoolBookings.
     * @example
     * // Update many PoolBookings
     * const poolBookings = await prisma.poolBookings.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more PoolBookings and only return the `id`
     * const poolBookingsWithIdOnly = await prisma.poolBookings.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends PoolBookingsUpdateManyAndReturnArgs>(args: SelectSubset<T, PoolBookingsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PoolBookingsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one PoolBookings.
     * @param {PoolBookingsUpsertArgs} args - Arguments to update or create a PoolBookings.
     * @example
     * // Update or create a PoolBookings
     * const poolBookings = await prisma.poolBookings.upsert({
     *   create: {
     *     // ... data to create a PoolBookings
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the PoolBookings we want to update
     *   }
     * })
     */
    upsert<T extends PoolBookingsUpsertArgs>(args: SelectSubset<T, PoolBookingsUpsertArgs<ExtArgs>>): Prisma__PoolBookingsClient<$Result.GetResult<Prisma.$PoolBookingsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of PoolBookings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolBookingsCountArgs} args - Arguments to filter PoolBookings to count.
     * @example
     * // Count the number of PoolBookings
     * const count = await prisma.poolBookings.count({
     *   where: {
     *     // ... the filter for the PoolBookings we want to count
     *   }
     * })
    **/
    count<T extends PoolBookingsCountArgs>(
      args?: Subset<T, PoolBookingsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PoolBookingsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a PoolBookings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolBookingsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PoolBookingsAggregateArgs>(args: Subset<T, PoolBookingsAggregateArgs>): Prisma.PrismaPromise<GetPoolBookingsAggregateType<T>>

    /**
     * Group by PoolBookings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PoolBookingsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PoolBookingsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PoolBookingsGroupByArgs['orderBy'] }
        : { orderBy?: PoolBookingsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PoolBookingsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPoolBookingsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the PoolBookings model
   */
  readonly fields: PoolBookingsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for PoolBookings.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PoolBookingsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    poolTable<T extends PoolTablesDefaultArgs<ExtArgs> = {}>(args?: Subset<T, PoolTablesDefaultArgs<ExtArgs>>): Prisma__PoolTablesClient<$Result.GetResult<Prisma.$PoolTablesPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the PoolBookings model
   */
  interface PoolBookingsFieldRefs {
    readonly id: FieldRef<"PoolBookings", 'Int'>
    readonly customer_name: FieldRef<"PoolBookings", 'String'>
    readonly tableId: FieldRef<"PoolBookings", 'Int'>
    readonly startTime: FieldRef<"PoolBookings", 'DateTime'>
    readonly endTime: FieldRef<"PoolBookings", 'DateTime'>
    readonly durationHours: FieldRef<"PoolBookings", 'Float'>
    readonly hourlyRate: FieldRef<"PoolBookings", 'Float'>
    readonly totalPrice: FieldRef<"PoolBookings", 'Float'>
    readonly status: FieldRef<"PoolBookings", 'BookingStatus'>
    readonly initialLightStatus: FieldRef<"PoolBookings", 'String'>
    readonly notes: FieldRef<"PoolBookings", 'String'>
    readonly createdAt: FieldRef<"PoolBookings", 'DateTime'>
    readonly updatedAt: FieldRef<"PoolBookings", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * PoolBookings findUnique
   */
  export type PoolBookingsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolBookings
     */
    select?: PoolBookingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolBookings
     */
    omit?: PoolBookingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolBookingsInclude<ExtArgs> | null
    /**
     * Filter, which PoolBookings to fetch.
     */
    where: PoolBookingsWhereUniqueInput
  }

  /**
   * PoolBookings findUniqueOrThrow
   */
  export type PoolBookingsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolBookings
     */
    select?: PoolBookingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolBookings
     */
    omit?: PoolBookingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolBookingsInclude<ExtArgs> | null
    /**
     * Filter, which PoolBookings to fetch.
     */
    where: PoolBookingsWhereUniqueInput
  }

  /**
   * PoolBookings findFirst
   */
  export type PoolBookingsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolBookings
     */
    select?: PoolBookingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolBookings
     */
    omit?: PoolBookingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolBookingsInclude<ExtArgs> | null
    /**
     * Filter, which PoolBookings to fetch.
     */
    where?: PoolBookingsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PoolBookings to fetch.
     */
    orderBy?: PoolBookingsOrderByWithRelationInput | PoolBookingsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PoolBookings.
     */
    cursor?: PoolBookingsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PoolBookings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PoolBookings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PoolBookings.
     */
    distinct?: PoolBookingsScalarFieldEnum | PoolBookingsScalarFieldEnum[]
  }

  /**
   * PoolBookings findFirstOrThrow
   */
  export type PoolBookingsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolBookings
     */
    select?: PoolBookingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolBookings
     */
    omit?: PoolBookingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolBookingsInclude<ExtArgs> | null
    /**
     * Filter, which PoolBookings to fetch.
     */
    where?: PoolBookingsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PoolBookings to fetch.
     */
    orderBy?: PoolBookingsOrderByWithRelationInput | PoolBookingsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for PoolBookings.
     */
    cursor?: PoolBookingsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PoolBookings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PoolBookings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of PoolBookings.
     */
    distinct?: PoolBookingsScalarFieldEnum | PoolBookingsScalarFieldEnum[]
  }

  /**
   * PoolBookings findMany
   */
  export type PoolBookingsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolBookings
     */
    select?: PoolBookingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolBookings
     */
    omit?: PoolBookingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolBookingsInclude<ExtArgs> | null
    /**
     * Filter, which PoolBookings to fetch.
     */
    where?: PoolBookingsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of PoolBookings to fetch.
     */
    orderBy?: PoolBookingsOrderByWithRelationInput | PoolBookingsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing PoolBookings.
     */
    cursor?: PoolBookingsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` PoolBookings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` PoolBookings.
     */
    skip?: number
    distinct?: PoolBookingsScalarFieldEnum | PoolBookingsScalarFieldEnum[]
  }

  /**
   * PoolBookings create
   */
  export type PoolBookingsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolBookings
     */
    select?: PoolBookingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolBookings
     */
    omit?: PoolBookingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolBookingsInclude<ExtArgs> | null
    /**
     * The data needed to create a PoolBookings.
     */
    data: XOR<PoolBookingsCreateInput, PoolBookingsUncheckedCreateInput>
  }

  /**
   * PoolBookings createMany
   */
  export type PoolBookingsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many PoolBookings.
     */
    data: PoolBookingsCreateManyInput | PoolBookingsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * PoolBookings createManyAndReturn
   */
  export type PoolBookingsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolBookings
     */
    select?: PoolBookingsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PoolBookings
     */
    omit?: PoolBookingsOmit<ExtArgs> | null
    /**
     * The data used to create many PoolBookings.
     */
    data: PoolBookingsCreateManyInput | PoolBookingsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolBookingsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * PoolBookings update
   */
  export type PoolBookingsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolBookings
     */
    select?: PoolBookingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolBookings
     */
    omit?: PoolBookingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolBookingsInclude<ExtArgs> | null
    /**
     * The data needed to update a PoolBookings.
     */
    data: XOR<PoolBookingsUpdateInput, PoolBookingsUncheckedUpdateInput>
    /**
     * Choose, which PoolBookings to update.
     */
    where: PoolBookingsWhereUniqueInput
  }

  /**
   * PoolBookings updateMany
   */
  export type PoolBookingsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update PoolBookings.
     */
    data: XOR<PoolBookingsUpdateManyMutationInput, PoolBookingsUncheckedUpdateManyInput>
    /**
     * Filter which PoolBookings to update
     */
    where?: PoolBookingsWhereInput
    /**
     * Limit how many PoolBookings to update.
     */
    limit?: number
  }

  /**
   * PoolBookings updateManyAndReturn
   */
  export type PoolBookingsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolBookings
     */
    select?: PoolBookingsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the PoolBookings
     */
    omit?: PoolBookingsOmit<ExtArgs> | null
    /**
     * The data used to update PoolBookings.
     */
    data: XOR<PoolBookingsUpdateManyMutationInput, PoolBookingsUncheckedUpdateManyInput>
    /**
     * Filter which PoolBookings to update
     */
    where?: PoolBookingsWhereInput
    /**
     * Limit how many PoolBookings to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolBookingsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * PoolBookings upsert
   */
  export type PoolBookingsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolBookings
     */
    select?: PoolBookingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolBookings
     */
    omit?: PoolBookingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolBookingsInclude<ExtArgs> | null
    /**
     * The filter to search for the PoolBookings to update in case it exists.
     */
    where: PoolBookingsWhereUniqueInput
    /**
     * In case the PoolBookings found by the `where` argument doesn't exist, create a new PoolBookings with this data.
     */
    create: XOR<PoolBookingsCreateInput, PoolBookingsUncheckedCreateInput>
    /**
     * In case the PoolBookings was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PoolBookingsUpdateInput, PoolBookingsUncheckedUpdateInput>
  }

  /**
   * PoolBookings delete
   */
  export type PoolBookingsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolBookings
     */
    select?: PoolBookingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolBookings
     */
    omit?: PoolBookingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolBookingsInclude<ExtArgs> | null
    /**
     * Filter which PoolBookings to delete.
     */
    where: PoolBookingsWhereUniqueInput
  }

  /**
   * PoolBookings deleteMany
   */
  export type PoolBookingsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which PoolBookings to delete
     */
    where?: PoolBookingsWhereInput
    /**
     * Limit how many PoolBookings to delete.
     */
    limit?: number
  }

  /**
   * PoolBookings without action
   */
  export type PoolBookingsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the PoolBookings
     */
    select?: PoolBookingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the PoolBookings
     */
    omit?: PoolBookingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PoolBookingsInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const PoolTablesScalarFieldEnum: {
    id: 'id',
    name: 'name',
    light_pin: 'light_pin',
    light_status: 'light_status',
    hourly_rate: 'hourly_rate',
    status: 'status'
  };

  export type PoolTablesScalarFieldEnum = (typeof PoolTablesScalarFieldEnum)[keyof typeof PoolTablesScalarFieldEnum]


  export const PoolBookingsScalarFieldEnum: {
    id: 'id',
    customer_name: 'customer_name',
    tableId: 'tableId',
    startTime: 'startTime',
    endTime: 'endTime',
    durationHours: 'durationHours',
    hourlyRate: 'hourlyRate',
    totalPrice: 'totalPrice',
    status: 'status',
    initialLightStatus: 'initialLightStatus',
    notes: 'notes',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type PoolBookingsScalarFieldEnum = (typeof PoolBookingsScalarFieldEnum)[keyof typeof PoolBookingsScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'PoolTableLightStatus'
   */
  export type EnumPoolTableLightStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PoolTableLightStatus'>
    


  /**
   * Reference to a field of type 'PoolTableLightStatus[]'
   */
  export type ListEnumPoolTableLightStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PoolTableLightStatus[]'>
    


  /**
   * Reference to a field of type 'Decimal'
   */
  export type DecimalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Decimal'>
    


  /**
   * Reference to a field of type 'Decimal[]'
   */
  export type ListDecimalFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Decimal[]'>
    


  /**
   * Reference to a field of type 'PoolTableStatus'
   */
  export type EnumPoolTableStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PoolTableStatus'>
    


  /**
   * Reference to a field of type 'PoolTableStatus[]'
   */
  export type ListEnumPoolTableStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'PoolTableStatus[]'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    


  /**
   * Reference to a field of type 'BookingStatus'
   */
  export type EnumBookingStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BookingStatus'>
    


  /**
   * Reference to a field of type 'BookingStatus[]'
   */
  export type ListEnumBookingStatusFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'BookingStatus[]'>
    
  /**
   * Deep Input Types
   */


  export type PoolTablesWhereInput = {
    AND?: PoolTablesWhereInput | PoolTablesWhereInput[]
    OR?: PoolTablesWhereInput[]
    NOT?: PoolTablesWhereInput | PoolTablesWhereInput[]
    id?: IntFilter<"PoolTables"> | number
    name?: StringFilter<"PoolTables"> | string
    light_pin?: StringFilter<"PoolTables"> | string
    light_status?: EnumPoolTableLightStatusFilter<"PoolTables"> | $Enums.PoolTableLightStatus
    hourly_rate?: DecimalFilter<"PoolTables"> | Decimal | DecimalJsLike | number | string
    status?: EnumPoolTableStatusFilter<"PoolTables"> | $Enums.PoolTableStatus
    PoolBookings?: PoolBookingsListRelationFilter
  }

  export type PoolTablesOrderByWithRelationInput = {
    id?: SortOrder
    name?: SortOrder
    light_pin?: SortOrder
    light_status?: SortOrder
    hourly_rate?: SortOrder
    status?: SortOrder
    PoolBookings?: PoolBookingsOrderByRelationAggregateInput
  }

  export type PoolTablesWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: PoolTablesWhereInput | PoolTablesWhereInput[]
    OR?: PoolTablesWhereInput[]
    NOT?: PoolTablesWhereInput | PoolTablesWhereInput[]
    name?: StringFilter<"PoolTables"> | string
    light_pin?: StringFilter<"PoolTables"> | string
    light_status?: EnumPoolTableLightStatusFilter<"PoolTables"> | $Enums.PoolTableLightStatus
    hourly_rate?: DecimalFilter<"PoolTables"> | Decimal | DecimalJsLike | number | string
    status?: EnumPoolTableStatusFilter<"PoolTables"> | $Enums.PoolTableStatus
    PoolBookings?: PoolBookingsListRelationFilter
  }, "id">

  export type PoolTablesOrderByWithAggregationInput = {
    id?: SortOrder
    name?: SortOrder
    light_pin?: SortOrder
    light_status?: SortOrder
    hourly_rate?: SortOrder
    status?: SortOrder
    _count?: PoolTablesCountOrderByAggregateInput
    _avg?: PoolTablesAvgOrderByAggregateInput
    _max?: PoolTablesMaxOrderByAggregateInput
    _min?: PoolTablesMinOrderByAggregateInput
    _sum?: PoolTablesSumOrderByAggregateInput
  }

  export type PoolTablesScalarWhereWithAggregatesInput = {
    AND?: PoolTablesScalarWhereWithAggregatesInput | PoolTablesScalarWhereWithAggregatesInput[]
    OR?: PoolTablesScalarWhereWithAggregatesInput[]
    NOT?: PoolTablesScalarWhereWithAggregatesInput | PoolTablesScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"PoolTables"> | number
    name?: StringWithAggregatesFilter<"PoolTables"> | string
    light_pin?: StringWithAggregatesFilter<"PoolTables"> | string
    light_status?: EnumPoolTableLightStatusWithAggregatesFilter<"PoolTables"> | $Enums.PoolTableLightStatus
    hourly_rate?: DecimalWithAggregatesFilter<"PoolTables"> | Decimal | DecimalJsLike | number | string
    status?: EnumPoolTableStatusWithAggregatesFilter<"PoolTables"> | $Enums.PoolTableStatus
  }

  export type PoolBookingsWhereInput = {
    AND?: PoolBookingsWhereInput | PoolBookingsWhereInput[]
    OR?: PoolBookingsWhereInput[]
    NOT?: PoolBookingsWhereInput | PoolBookingsWhereInput[]
    id?: IntFilter<"PoolBookings"> | number
    customer_name?: StringNullableFilter<"PoolBookings"> | string | null
    tableId?: IntFilter<"PoolBookings"> | number
    startTime?: DateTimeFilter<"PoolBookings"> | Date | string
    endTime?: DateTimeNullableFilter<"PoolBookings"> | Date | string | null
    durationHours?: FloatNullableFilter<"PoolBookings"> | number | null
    hourlyRate?: FloatFilter<"PoolBookings"> | number
    totalPrice?: FloatNullableFilter<"PoolBookings"> | number | null
    status?: EnumBookingStatusFilter<"PoolBookings"> | $Enums.BookingStatus
    initialLightStatus?: StringNullableFilter<"PoolBookings"> | string | null
    notes?: StringNullableFilter<"PoolBookings"> | string | null
    createdAt?: DateTimeFilter<"PoolBookings"> | Date | string
    updatedAt?: DateTimeFilter<"PoolBookings"> | Date | string
    poolTable?: XOR<PoolTablesScalarRelationFilter, PoolTablesWhereInput>
  }

  export type PoolBookingsOrderByWithRelationInput = {
    id?: SortOrder
    customer_name?: SortOrderInput | SortOrder
    tableId?: SortOrder
    startTime?: SortOrder
    endTime?: SortOrderInput | SortOrder
    durationHours?: SortOrderInput | SortOrder
    hourlyRate?: SortOrder
    totalPrice?: SortOrderInput | SortOrder
    status?: SortOrder
    initialLightStatus?: SortOrderInput | SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    poolTable?: PoolTablesOrderByWithRelationInput
  }

  export type PoolBookingsWhereUniqueInput = Prisma.AtLeast<{
    id?: number
    AND?: PoolBookingsWhereInput | PoolBookingsWhereInput[]
    OR?: PoolBookingsWhereInput[]
    NOT?: PoolBookingsWhereInput | PoolBookingsWhereInput[]
    customer_name?: StringNullableFilter<"PoolBookings"> | string | null
    tableId?: IntFilter<"PoolBookings"> | number
    startTime?: DateTimeFilter<"PoolBookings"> | Date | string
    endTime?: DateTimeNullableFilter<"PoolBookings"> | Date | string | null
    durationHours?: FloatNullableFilter<"PoolBookings"> | number | null
    hourlyRate?: FloatFilter<"PoolBookings"> | number
    totalPrice?: FloatNullableFilter<"PoolBookings"> | number | null
    status?: EnumBookingStatusFilter<"PoolBookings"> | $Enums.BookingStatus
    initialLightStatus?: StringNullableFilter<"PoolBookings"> | string | null
    notes?: StringNullableFilter<"PoolBookings"> | string | null
    createdAt?: DateTimeFilter<"PoolBookings"> | Date | string
    updatedAt?: DateTimeFilter<"PoolBookings"> | Date | string
    poolTable?: XOR<PoolTablesScalarRelationFilter, PoolTablesWhereInput>
  }, "id">

  export type PoolBookingsOrderByWithAggregationInput = {
    id?: SortOrder
    customer_name?: SortOrderInput | SortOrder
    tableId?: SortOrder
    startTime?: SortOrder
    endTime?: SortOrderInput | SortOrder
    durationHours?: SortOrderInput | SortOrder
    hourlyRate?: SortOrder
    totalPrice?: SortOrderInput | SortOrder
    status?: SortOrder
    initialLightStatus?: SortOrderInput | SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: PoolBookingsCountOrderByAggregateInput
    _avg?: PoolBookingsAvgOrderByAggregateInput
    _max?: PoolBookingsMaxOrderByAggregateInput
    _min?: PoolBookingsMinOrderByAggregateInput
    _sum?: PoolBookingsSumOrderByAggregateInput
  }

  export type PoolBookingsScalarWhereWithAggregatesInput = {
    AND?: PoolBookingsScalarWhereWithAggregatesInput | PoolBookingsScalarWhereWithAggregatesInput[]
    OR?: PoolBookingsScalarWhereWithAggregatesInput[]
    NOT?: PoolBookingsScalarWhereWithAggregatesInput | PoolBookingsScalarWhereWithAggregatesInput[]
    id?: IntWithAggregatesFilter<"PoolBookings"> | number
    customer_name?: StringNullableWithAggregatesFilter<"PoolBookings"> | string | null
    tableId?: IntWithAggregatesFilter<"PoolBookings"> | number
    startTime?: DateTimeWithAggregatesFilter<"PoolBookings"> | Date | string
    endTime?: DateTimeNullableWithAggregatesFilter<"PoolBookings"> | Date | string | null
    durationHours?: FloatNullableWithAggregatesFilter<"PoolBookings"> | number | null
    hourlyRate?: FloatWithAggregatesFilter<"PoolBookings"> | number
    totalPrice?: FloatNullableWithAggregatesFilter<"PoolBookings"> | number | null
    status?: EnumBookingStatusWithAggregatesFilter<"PoolBookings"> | $Enums.BookingStatus
    initialLightStatus?: StringNullableWithAggregatesFilter<"PoolBookings"> | string | null
    notes?: StringNullableWithAggregatesFilter<"PoolBookings"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"PoolBookings"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"PoolBookings"> | Date | string
  }

  export type PoolTablesCreateInput = {
    name: string
    light_pin: string
    light_status?: $Enums.PoolTableLightStatus
    hourly_rate?: Decimal | DecimalJsLike | number | string
    status?: $Enums.PoolTableStatus
    PoolBookings?: PoolBookingsCreateNestedManyWithoutPoolTableInput
  }

  export type PoolTablesUncheckedCreateInput = {
    id?: number
    name: string
    light_pin: string
    light_status?: $Enums.PoolTableLightStatus
    hourly_rate?: Decimal | DecimalJsLike | number | string
    status?: $Enums.PoolTableStatus
    PoolBookings?: PoolBookingsUncheckedCreateNestedManyWithoutPoolTableInput
  }

  export type PoolTablesUpdateInput = {
    name?: StringFieldUpdateOperationsInput | string
    light_pin?: StringFieldUpdateOperationsInput | string
    light_status?: EnumPoolTableLightStatusFieldUpdateOperationsInput | $Enums.PoolTableLightStatus
    hourly_rate?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: EnumPoolTableStatusFieldUpdateOperationsInput | $Enums.PoolTableStatus
    PoolBookings?: PoolBookingsUpdateManyWithoutPoolTableNestedInput
  }

  export type PoolTablesUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    light_pin?: StringFieldUpdateOperationsInput | string
    light_status?: EnumPoolTableLightStatusFieldUpdateOperationsInput | $Enums.PoolTableLightStatus
    hourly_rate?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: EnumPoolTableStatusFieldUpdateOperationsInput | $Enums.PoolTableStatus
    PoolBookings?: PoolBookingsUncheckedUpdateManyWithoutPoolTableNestedInput
  }

  export type PoolTablesCreateManyInput = {
    id?: number
    name: string
    light_pin: string
    light_status?: $Enums.PoolTableLightStatus
    hourly_rate?: Decimal | DecimalJsLike | number | string
    status?: $Enums.PoolTableStatus
  }

  export type PoolTablesUpdateManyMutationInput = {
    name?: StringFieldUpdateOperationsInput | string
    light_pin?: StringFieldUpdateOperationsInput | string
    light_status?: EnumPoolTableLightStatusFieldUpdateOperationsInput | $Enums.PoolTableLightStatus
    hourly_rate?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: EnumPoolTableStatusFieldUpdateOperationsInput | $Enums.PoolTableStatus
  }

  export type PoolTablesUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    light_pin?: StringFieldUpdateOperationsInput | string
    light_status?: EnumPoolTableLightStatusFieldUpdateOperationsInput | $Enums.PoolTableLightStatus
    hourly_rate?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: EnumPoolTableStatusFieldUpdateOperationsInput | $Enums.PoolTableStatus
  }

  export type PoolBookingsCreateInput = {
    customer_name?: string | null
    startTime: Date | string
    endTime?: Date | string | null
    durationHours?: number | null
    hourlyRate: number
    totalPrice?: number | null
    status?: $Enums.BookingStatus
    initialLightStatus?: string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    poolTable: PoolTablesCreateNestedOneWithoutPoolBookingsInput
  }

  export type PoolBookingsUncheckedCreateInput = {
    id?: number
    customer_name?: string | null
    tableId: number
    startTime: Date | string
    endTime?: Date | string | null
    durationHours?: number | null
    hourlyRate: number
    totalPrice?: number | null
    status?: $Enums.BookingStatus
    initialLightStatus?: string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PoolBookingsUpdateInput = {
    customer_name?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    durationHours?: NullableFloatFieldUpdateOperationsInput | number | null
    hourlyRate?: FloatFieldUpdateOperationsInput | number
    totalPrice?: NullableFloatFieldUpdateOperationsInput | number | null
    status?: EnumBookingStatusFieldUpdateOperationsInput | $Enums.BookingStatus
    initialLightStatus?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    poolTable?: PoolTablesUpdateOneRequiredWithoutPoolBookingsNestedInput
  }

  export type PoolBookingsUncheckedUpdateInput = {
    id?: IntFieldUpdateOperationsInput | number
    customer_name?: NullableStringFieldUpdateOperationsInput | string | null
    tableId?: IntFieldUpdateOperationsInput | number
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    durationHours?: NullableFloatFieldUpdateOperationsInput | number | null
    hourlyRate?: FloatFieldUpdateOperationsInput | number
    totalPrice?: NullableFloatFieldUpdateOperationsInput | number | null
    status?: EnumBookingStatusFieldUpdateOperationsInput | $Enums.BookingStatus
    initialLightStatus?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PoolBookingsCreateManyInput = {
    id?: number
    customer_name?: string | null
    tableId: number
    startTime: Date | string
    endTime?: Date | string | null
    durationHours?: number | null
    hourlyRate: number
    totalPrice?: number | null
    status?: $Enums.BookingStatus
    initialLightStatus?: string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PoolBookingsUpdateManyMutationInput = {
    customer_name?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    durationHours?: NullableFloatFieldUpdateOperationsInput | number | null
    hourlyRate?: FloatFieldUpdateOperationsInput | number
    totalPrice?: NullableFloatFieldUpdateOperationsInput | number | null
    status?: EnumBookingStatusFieldUpdateOperationsInput | $Enums.BookingStatus
    initialLightStatus?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PoolBookingsUncheckedUpdateManyInput = {
    id?: IntFieldUpdateOperationsInput | number
    customer_name?: NullableStringFieldUpdateOperationsInput | string | null
    tableId?: IntFieldUpdateOperationsInput | number
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    durationHours?: NullableFloatFieldUpdateOperationsInput | number | null
    hourlyRate?: FloatFieldUpdateOperationsInput | number
    totalPrice?: NullableFloatFieldUpdateOperationsInput | number | null
    status?: EnumBookingStatusFieldUpdateOperationsInput | $Enums.BookingStatus
    initialLightStatus?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type EnumPoolTableLightStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.PoolTableLightStatus | EnumPoolTableLightStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PoolTableLightStatus[] | ListEnumPoolTableLightStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.PoolTableLightStatus[] | ListEnumPoolTableLightStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumPoolTableLightStatusFilter<$PrismaModel> | $Enums.PoolTableLightStatus
  }

  export type DecimalFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
  }

  export type EnumPoolTableStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.PoolTableStatus | EnumPoolTableStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PoolTableStatus[] | ListEnumPoolTableStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.PoolTableStatus[] | ListEnumPoolTableStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumPoolTableStatusFilter<$PrismaModel> | $Enums.PoolTableStatus
  }

  export type PoolBookingsListRelationFilter = {
    every?: PoolBookingsWhereInput
    some?: PoolBookingsWhereInput
    none?: PoolBookingsWhereInput
  }

  export type PoolBookingsOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type PoolTablesCountOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    light_pin?: SortOrder
    light_status?: SortOrder
    hourly_rate?: SortOrder
    status?: SortOrder
  }

  export type PoolTablesAvgOrderByAggregateInput = {
    id?: SortOrder
    hourly_rate?: SortOrder
  }

  export type PoolTablesMaxOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    light_pin?: SortOrder
    light_status?: SortOrder
    hourly_rate?: SortOrder
    status?: SortOrder
  }

  export type PoolTablesMinOrderByAggregateInput = {
    id?: SortOrder
    name?: SortOrder
    light_pin?: SortOrder
    light_status?: SortOrder
    hourly_rate?: SortOrder
    status?: SortOrder
  }

  export type PoolTablesSumOrderByAggregateInput = {
    id?: SortOrder
    hourly_rate?: SortOrder
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type EnumPoolTableLightStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PoolTableLightStatus | EnumPoolTableLightStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PoolTableLightStatus[] | ListEnumPoolTableLightStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.PoolTableLightStatus[] | ListEnumPoolTableLightStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumPoolTableLightStatusWithAggregatesFilter<$PrismaModel> | $Enums.PoolTableLightStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPoolTableLightStatusFilter<$PrismaModel>
    _max?: NestedEnumPoolTableLightStatusFilter<$PrismaModel>
  }

  export type DecimalWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedDecimalFilter<$PrismaModel>
    _sum?: NestedDecimalFilter<$PrismaModel>
    _min?: NestedDecimalFilter<$PrismaModel>
    _max?: NestedDecimalFilter<$PrismaModel>
  }

  export type EnumPoolTableStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PoolTableStatus | EnumPoolTableStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PoolTableStatus[] | ListEnumPoolTableStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.PoolTableStatus[] | ListEnumPoolTableStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumPoolTableStatusWithAggregatesFilter<$PrismaModel> | $Enums.PoolTableStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPoolTableStatusFilter<$PrismaModel>
    _max?: NestedEnumPoolTableStatusFilter<$PrismaModel>
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type FloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type FloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type EnumBookingStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.BookingStatus | EnumBookingStatusFieldRefInput<$PrismaModel>
    in?: $Enums.BookingStatus[] | ListEnumBookingStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.BookingStatus[] | ListEnumBookingStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumBookingStatusFilter<$PrismaModel> | $Enums.BookingStatus
  }

  export type PoolTablesScalarRelationFilter = {
    is?: PoolTablesWhereInput
    isNot?: PoolTablesWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type PoolBookingsCountOrderByAggregateInput = {
    id?: SortOrder
    customer_name?: SortOrder
    tableId?: SortOrder
    startTime?: SortOrder
    endTime?: SortOrder
    durationHours?: SortOrder
    hourlyRate?: SortOrder
    totalPrice?: SortOrder
    status?: SortOrder
    initialLightStatus?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PoolBookingsAvgOrderByAggregateInput = {
    id?: SortOrder
    tableId?: SortOrder
    durationHours?: SortOrder
    hourlyRate?: SortOrder
    totalPrice?: SortOrder
  }

  export type PoolBookingsMaxOrderByAggregateInput = {
    id?: SortOrder
    customer_name?: SortOrder
    tableId?: SortOrder
    startTime?: SortOrder
    endTime?: SortOrder
    durationHours?: SortOrder
    hourlyRate?: SortOrder
    totalPrice?: SortOrder
    status?: SortOrder
    initialLightStatus?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PoolBookingsMinOrderByAggregateInput = {
    id?: SortOrder
    customer_name?: SortOrder
    tableId?: SortOrder
    startTime?: SortOrder
    endTime?: SortOrder
    durationHours?: SortOrder
    hourlyRate?: SortOrder
    totalPrice?: SortOrder
    status?: SortOrder
    initialLightStatus?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type PoolBookingsSumOrderByAggregateInput = {
    id?: SortOrder
    tableId?: SortOrder
    durationHours?: SortOrder
    hourlyRate?: SortOrder
    totalPrice?: SortOrder
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type FloatNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedFloatNullableFilter<$PrismaModel>
    _min?: NestedFloatNullableFilter<$PrismaModel>
    _max?: NestedFloatNullableFilter<$PrismaModel>
  }

  export type FloatWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedFloatFilter<$PrismaModel>
    _min?: NestedFloatFilter<$PrismaModel>
    _max?: NestedFloatFilter<$PrismaModel>
  }

  export type EnumBookingStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.BookingStatus | EnumBookingStatusFieldRefInput<$PrismaModel>
    in?: $Enums.BookingStatus[] | ListEnumBookingStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.BookingStatus[] | ListEnumBookingStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumBookingStatusWithAggregatesFilter<$PrismaModel> | $Enums.BookingStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumBookingStatusFilter<$PrismaModel>
    _max?: NestedEnumBookingStatusFilter<$PrismaModel>
  }

  export type PoolBookingsCreateNestedManyWithoutPoolTableInput = {
    create?: XOR<PoolBookingsCreateWithoutPoolTableInput, PoolBookingsUncheckedCreateWithoutPoolTableInput> | PoolBookingsCreateWithoutPoolTableInput[] | PoolBookingsUncheckedCreateWithoutPoolTableInput[]
    connectOrCreate?: PoolBookingsCreateOrConnectWithoutPoolTableInput | PoolBookingsCreateOrConnectWithoutPoolTableInput[]
    createMany?: PoolBookingsCreateManyPoolTableInputEnvelope
    connect?: PoolBookingsWhereUniqueInput | PoolBookingsWhereUniqueInput[]
  }

  export type PoolBookingsUncheckedCreateNestedManyWithoutPoolTableInput = {
    create?: XOR<PoolBookingsCreateWithoutPoolTableInput, PoolBookingsUncheckedCreateWithoutPoolTableInput> | PoolBookingsCreateWithoutPoolTableInput[] | PoolBookingsUncheckedCreateWithoutPoolTableInput[]
    connectOrCreate?: PoolBookingsCreateOrConnectWithoutPoolTableInput | PoolBookingsCreateOrConnectWithoutPoolTableInput[]
    createMany?: PoolBookingsCreateManyPoolTableInputEnvelope
    connect?: PoolBookingsWhereUniqueInput | PoolBookingsWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type EnumPoolTableLightStatusFieldUpdateOperationsInput = {
    set?: $Enums.PoolTableLightStatus
  }

  export type DecimalFieldUpdateOperationsInput = {
    set?: Decimal | DecimalJsLike | number | string
    increment?: Decimal | DecimalJsLike | number | string
    decrement?: Decimal | DecimalJsLike | number | string
    multiply?: Decimal | DecimalJsLike | number | string
    divide?: Decimal | DecimalJsLike | number | string
  }

  export type EnumPoolTableStatusFieldUpdateOperationsInput = {
    set?: $Enums.PoolTableStatus
  }

  export type PoolBookingsUpdateManyWithoutPoolTableNestedInput = {
    create?: XOR<PoolBookingsCreateWithoutPoolTableInput, PoolBookingsUncheckedCreateWithoutPoolTableInput> | PoolBookingsCreateWithoutPoolTableInput[] | PoolBookingsUncheckedCreateWithoutPoolTableInput[]
    connectOrCreate?: PoolBookingsCreateOrConnectWithoutPoolTableInput | PoolBookingsCreateOrConnectWithoutPoolTableInput[]
    upsert?: PoolBookingsUpsertWithWhereUniqueWithoutPoolTableInput | PoolBookingsUpsertWithWhereUniqueWithoutPoolTableInput[]
    createMany?: PoolBookingsCreateManyPoolTableInputEnvelope
    set?: PoolBookingsWhereUniqueInput | PoolBookingsWhereUniqueInput[]
    disconnect?: PoolBookingsWhereUniqueInput | PoolBookingsWhereUniqueInput[]
    delete?: PoolBookingsWhereUniqueInput | PoolBookingsWhereUniqueInput[]
    connect?: PoolBookingsWhereUniqueInput | PoolBookingsWhereUniqueInput[]
    update?: PoolBookingsUpdateWithWhereUniqueWithoutPoolTableInput | PoolBookingsUpdateWithWhereUniqueWithoutPoolTableInput[]
    updateMany?: PoolBookingsUpdateManyWithWhereWithoutPoolTableInput | PoolBookingsUpdateManyWithWhereWithoutPoolTableInput[]
    deleteMany?: PoolBookingsScalarWhereInput | PoolBookingsScalarWhereInput[]
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type PoolBookingsUncheckedUpdateManyWithoutPoolTableNestedInput = {
    create?: XOR<PoolBookingsCreateWithoutPoolTableInput, PoolBookingsUncheckedCreateWithoutPoolTableInput> | PoolBookingsCreateWithoutPoolTableInput[] | PoolBookingsUncheckedCreateWithoutPoolTableInput[]
    connectOrCreate?: PoolBookingsCreateOrConnectWithoutPoolTableInput | PoolBookingsCreateOrConnectWithoutPoolTableInput[]
    upsert?: PoolBookingsUpsertWithWhereUniqueWithoutPoolTableInput | PoolBookingsUpsertWithWhereUniqueWithoutPoolTableInput[]
    createMany?: PoolBookingsCreateManyPoolTableInputEnvelope
    set?: PoolBookingsWhereUniqueInput | PoolBookingsWhereUniqueInput[]
    disconnect?: PoolBookingsWhereUniqueInput | PoolBookingsWhereUniqueInput[]
    delete?: PoolBookingsWhereUniqueInput | PoolBookingsWhereUniqueInput[]
    connect?: PoolBookingsWhereUniqueInput | PoolBookingsWhereUniqueInput[]
    update?: PoolBookingsUpdateWithWhereUniqueWithoutPoolTableInput | PoolBookingsUpdateWithWhereUniqueWithoutPoolTableInput[]
    updateMany?: PoolBookingsUpdateManyWithWhereWithoutPoolTableInput | PoolBookingsUpdateManyWithWhereWithoutPoolTableInput[]
    deleteMany?: PoolBookingsScalarWhereInput | PoolBookingsScalarWhereInput[]
  }

  export type PoolTablesCreateNestedOneWithoutPoolBookingsInput = {
    create?: XOR<PoolTablesCreateWithoutPoolBookingsInput, PoolTablesUncheckedCreateWithoutPoolBookingsInput>
    connectOrCreate?: PoolTablesCreateOrConnectWithoutPoolBookingsInput
    connect?: PoolTablesWhereUniqueInput
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type NullableFloatFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type FloatFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type EnumBookingStatusFieldUpdateOperationsInput = {
    set?: $Enums.BookingStatus
  }

  export type PoolTablesUpdateOneRequiredWithoutPoolBookingsNestedInput = {
    create?: XOR<PoolTablesCreateWithoutPoolBookingsInput, PoolTablesUncheckedCreateWithoutPoolBookingsInput>
    connectOrCreate?: PoolTablesCreateOrConnectWithoutPoolBookingsInput
    upsert?: PoolTablesUpsertWithoutPoolBookingsInput
    connect?: PoolTablesWhereUniqueInput
    update?: XOR<XOR<PoolTablesUpdateToOneWithWhereWithoutPoolBookingsInput, PoolTablesUpdateWithoutPoolBookingsInput>, PoolTablesUncheckedUpdateWithoutPoolBookingsInput>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedEnumPoolTableLightStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.PoolTableLightStatus | EnumPoolTableLightStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PoolTableLightStatus[] | ListEnumPoolTableLightStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.PoolTableLightStatus[] | ListEnumPoolTableLightStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumPoolTableLightStatusFilter<$PrismaModel> | $Enums.PoolTableLightStatus
  }

  export type NestedDecimalFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
  }

  export type NestedEnumPoolTableStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.PoolTableStatus | EnumPoolTableStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PoolTableStatus[] | ListEnumPoolTableStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.PoolTableStatus[] | ListEnumPoolTableStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumPoolTableStatusFilter<$PrismaModel> | $Enums.PoolTableStatus
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedEnumPoolTableLightStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PoolTableLightStatus | EnumPoolTableLightStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PoolTableLightStatus[] | ListEnumPoolTableLightStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.PoolTableLightStatus[] | ListEnumPoolTableLightStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumPoolTableLightStatusWithAggregatesFilter<$PrismaModel> | $Enums.PoolTableLightStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPoolTableLightStatusFilter<$PrismaModel>
    _max?: NestedEnumPoolTableLightStatusFilter<$PrismaModel>
  }

  export type NestedDecimalWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    in?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    notIn?: Decimal[] | DecimalJsLike[] | number[] | string[] | ListDecimalFieldRefInput<$PrismaModel>
    lt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    lte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gt?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    gte?: Decimal | DecimalJsLike | number | string | DecimalFieldRefInput<$PrismaModel>
    not?: NestedDecimalWithAggregatesFilter<$PrismaModel> | Decimal | DecimalJsLike | number | string
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedDecimalFilter<$PrismaModel>
    _sum?: NestedDecimalFilter<$PrismaModel>
    _min?: NestedDecimalFilter<$PrismaModel>
    _max?: NestedDecimalFilter<$PrismaModel>
  }

  export type NestedEnumPoolTableStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.PoolTableStatus | EnumPoolTableStatusFieldRefInput<$PrismaModel>
    in?: $Enums.PoolTableStatus[] | ListEnumPoolTableStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.PoolTableStatus[] | ListEnumPoolTableStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumPoolTableStatusWithAggregatesFilter<$PrismaModel> | $Enums.PoolTableStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumPoolTableStatusFilter<$PrismaModel>
    _max?: NestedEnumPoolTableStatusFilter<$PrismaModel>
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedEnumBookingStatusFilter<$PrismaModel = never> = {
    equals?: $Enums.BookingStatus | EnumBookingStatusFieldRefInput<$PrismaModel>
    in?: $Enums.BookingStatus[] | ListEnumBookingStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.BookingStatus[] | ListEnumBookingStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumBookingStatusFilter<$PrismaModel> | $Enums.BookingStatus
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedFloatNullableFilter<$PrismaModel>
    _min?: NestedFloatNullableFilter<$PrismaModel>
    _max?: NestedFloatNullableFilter<$PrismaModel>
  }

  export type NestedFloatWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedFloatFilter<$PrismaModel>
    _min?: NestedFloatFilter<$PrismaModel>
    _max?: NestedFloatFilter<$PrismaModel>
  }

  export type NestedEnumBookingStatusWithAggregatesFilter<$PrismaModel = never> = {
    equals?: $Enums.BookingStatus | EnumBookingStatusFieldRefInput<$PrismaModel>
    in?: $Enums.BookingStatus[] | ListEnumBookingStatusFieldRefInput<$PrismaModel>
    notIn?: $Enums.BookingStatus[] | ListEnumBookingStatusFieldRefInput<$PrismaModel>
    not?: NestedEnumBookingStatusWithAggregatesFilter<$PrismaModel> | $Enums.BookingStatus
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedEnumBookingStatusFilter<$PrismaModel>
    _max?: NestedEnumBookingStatusFilter<$PrismaModel>
  }

  export type PoolBookingsCreateWithoutPoolTableInput = {
    customer_name?: string | null
    startTime: Date | string
    endTime?: Date | string | null
    durationHours?: number | null
    hourlyRate: number
    totalPrice?: number | null
    status?: $Enums.BookingStatus
    initialLightStatus?: string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PoolBookingsUncheckedCreateWithoutPoolTableInput = {
    id?: number
    customer_name?: string | null
    startTime: Date | string
    endTime?: Date | string | null
    durationHours?: number | null
    hourlyRate: number
    totalPrice?: number | null
    status?: $Enums.BookingStatus
    initialLightStatus?: string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PoolBookingsCreateOrConnectWithoutPoolTableInput = {
    where: PoolBookingsWhereUniqueInput
    create: XOR<PoolBookingsCreateWithoutPoolTableInput, PoolBookingsUncheckedCreateWithoutPoolTableInput>
  }

  export type PoolBookingsCreateManyPoolTableInputEnvelope = {
    data: PoolBookingsCreateManyPoolTableInput | PoolBookingsCreateManyPoolTableInput[]
    skipDuplicates?: boolean
  }

  export type PoolBookingsUpsertWithWhereUniqueWithoutPoolTableInput = {
    where: PoolBookingsWhereUniqueInput
    update: XOR<PoolBookingsUpdateWithoutPoolTableInput, PoolBookingsUncheckedUpdateWithoutPoolTableInput>
    create: XOR<PoolBookingsCreateWithoutPoolTableInput, PoolBookingsUncheckedCreateWithoutPoolTableInput>
  }

  export type PoolBookingsUpdateWithWhereUniqueWithoutPoolTableInput = {
    where: PoolBookingsWhereUniqueInput
    data: XOR<PoolBookingsUpdateWithoutPoolTableInput, PoolBookingsUncheckedUpdateWithoutPoolTableInput>
  }

  export type PoolBookingsUpdateManyWithWhereWithoutPoolTableInput = {
    where: PoolBookingsScalarWhereInput
    data: XOR<PoolBookingsUpdateManyMutationInput, PoolBookingsUncheckedUpdateManyWithoutPoolTableInput>
  }

  export type PoolBookingsScalarWhereInput = {
    AND?: PoolBookingsScalarWhereInput | PoolBookingsScalarWhereInput[]
    OR?: PoolBookingsScalarWhereInput[]
    NOT?: PoolBookingsScalarWhereInput | PoolBookingsScalarWhereInput[]
    id?: IntFilter<"PoolBookings"> | number
    customer_name?: StringNullableFilter<"PoolBookings"> | string | null
    tableId?: IntFilter<"PoolBookings"> | number
    startTime?: DateTimeFilter<"PoolBookings"> | Date | string
    endTime?: DateTimeNullableFilter<"PoolBookings"> | Date | string | null
    durationHours?: FloatNullableFilter<"PoolBookings"> | number | null
    hourlyRate?: FloatFilter<"PoolBookings"> | number
    totalPrice?: FloatNullableFilter<"PoolBookings"> | number | null
    status?: EnumBookingStatusFilter<"PoolBookings"> | $Enums.BookingStatus
    initialLightStatus?: StringNullableFilter<"PoolBookings"> | string | null
    notes?: StringNullableFilter<"PoolBookings"> | string | null
    createdAt?: DateTimeFilter<"PoolBookings"> | Date | string
    updatedAt?: DateTimeFilter<"PoolBookings"> | Date | string
  }

  export type PoolTablesCreateWithoutPoolBookingsInput = {
    name: string
    light_pin: string
    light_status?: $Enums.PoolTableLightStatus
    hourly_rate?: Decimal | DecimalJsLike | number | string
    status?: $Enums.PoolTableStatus
  }

  export type PoolTablesUncheckedCreateWithoutPoolBookingsInput = {
    id?: number
    name: string
    light_pin: string
    light_status?: $Enums.PoolTableLightStatus
    hourly_rate?: Decimal | DecimalJsLike | number | string
    status?: $Enums.PoolTableStatus
  }

  export type PoolTablesCreateOrConnectWithoutPoolBookingsInput = {
    where: PoolTablesWhereUniqueInput
    create: XOR<PoolTablesCreateWithoutPoolBookingsInput, PoolTablesUncheckedCreateWithoutPoolBookingsInput>
  }

  export type PoolTablesUpsertWithoutPoolBookingsInput = {
    update: XOR<PoolTablesUpdateWithoutPoolBookingsInput, PoolTablesUncheckedUpdateWithoutPoolBookingsInput>
    create: XOR<PoolTablesCreateWithoutPoolBookingsInput, PoolTablesUncheckedCreateWithoutPoolBookingsInput>
    where?: PoolTablesWhereInput
  }

  export type PoolTablesUpdateToOneWithWhereWithoutPoolBookingsInput = {
    where?: PoolTablesWhereInput
    data: XOR<PoolTablesUpdateWithoutPoolBookingsInput, PoolTablesUncheckedUpdateWithoutPoolBookingsInput>
  }

  export type PoolTablesUpdateWithoutPoolBookingsInput = {
    name?: StringFieldUpdateOperationsInput | string
    light_pin?: StringFieldUpdateOperationsInput | string
    light_status?: EnumPoolTableLightStatusFieldUpdateOperationsInput | $Enums.PoolTableLightStatus
    hourly_rate?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: EnumPoolTableStatusFieldUpdateOperationsInput | $Enums.PoolTableStatus
  }

  export type PoolTablesUncheckedUpdateWithoutPoolBookingsInput = {
    id?: IntFieldUpdateOperationsInput | number
    name?: StringFieldUpdateOperationsInput | string
    light_pin?: StringFieldUpdateOperationsInput | string
    light_status?: EnumPoolTableLightStatusFieldUpdateOperationsInput | $Enums.PoolTableLightStatus
    hourly_rate?: DecimalFieldUpdateOperationsInput | Decimal | DecimalJsLike | number | string
    status?: EnumPoolTableStatusFieldUpdateOperationsInput | $Enums.PoolTableStatus
  }

  export type PoolBookingsCreateManyPoolTableInput = {
    id?: number
    customer_name?: string | null
    startTime: Date | string
    endTime?: Date | string | null
    durationHours?: number | null
    hourlyRate: number
    totalPrice?: number | null
    status?: $Enums.BookingStatus
    initialLightStatus?: string | null
    notes?: string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type PoolBookingsUpdateWithoutPoolTableInput = {
    customer_name?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    durationHours?: NullableFloatFieldUpdateOperationsInput | number | null
    hourlyRate?: FloatFieldUpdateOperationsInput | number
    totalPrice?: NullableFloatFieldUpdateOperationsInput | number | null
    status?: EnumBookingStatusFieldUpdateOperationsInput | $Enums.BookingStatus
    initialLightStatus?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PoolBookingsUncheckedUpdateWithoutPoolTableInput = {
    id?: IntFieldUpdateOperationsInput | number
    customer_name?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    durationHours?: NullableFloatFieldUpdateOperationsInput | number | null
    hourlyRate?: FloatFieldUpdateOperationsInput | number
    totalPrice?: NullableFloatFieldUpdateOperationsInput | number | null
    status?: EnumBookingStatusFieldUpdateOperationsInput | $Enums.BookingStatus
    initialLightStatus?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PoolBookingsUncheckedUpdateManyWithoutPoolTableInput = {
    id?: IntFieldUpdateOperationsInput | number
    customer_name?: NullableStringFieldUpdateOperationsInput | string | null
    startTime?: DateTimeFieldUpdateOperationsInput | Date | string
    endTime?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    durationHours?: NullableFloatFieldUpdateOperationsInput | number | null
    hourlyRate?: FloatFieldUpdateOperationsInput | number
    totalPrice?: NullableFloatFieldUpdateOperationsInput | number | null
    status?: EnumBookingStatusFieldUpdateOperationsInput | $Enums.BookingStatus
    initialLightStatus?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}