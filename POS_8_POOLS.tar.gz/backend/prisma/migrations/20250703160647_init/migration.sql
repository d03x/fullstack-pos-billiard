-- AlterTable
ALTER TABLE "lights" ADD COLUMN     "pin" TEXT;
