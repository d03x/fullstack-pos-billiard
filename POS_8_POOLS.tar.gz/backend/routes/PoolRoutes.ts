import type { FastifyInstance } from "fastify";
import { EspController } from "../controllers/EspController";
import { PoolController } from "../controllers/PoolController";

export const PoolRoutes = async (app: FastifyInstance) => {
  const prisma = app.prisma; // Access the Prisma client from the Fastify instance
  const TableController: PoolController = new PoolController(
    prisma
  );
  app.get("/api/pool-tables",TableController.get.bind(TableController));
};
