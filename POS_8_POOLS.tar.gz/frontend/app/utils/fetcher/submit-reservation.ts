import { api_url } from "../api";

export async function submitReservation(url: string, { arg }: { arg: any }) {
  const response = await fetch(`${api_url}${url}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(arg),
  });

  if (!response.ok) {
    throw new Error("Gagal menyimpan reservasi");
  }

  return response.json();
}
