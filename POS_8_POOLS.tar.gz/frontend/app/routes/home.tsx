import { Welcome } from "../welcome/welcome";


export default function Home() {
  return <Welcome />;
}
