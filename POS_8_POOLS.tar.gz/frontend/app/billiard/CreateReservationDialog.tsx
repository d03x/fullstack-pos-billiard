import { Dialog, DialogContent, DialogDescription, DialogTitle, DialogTrigger } from "~/components/ui/dialog";
import dayjs from "dayjs";
import { BadgeInfo, InfoIcon } from "lucide-react";
import { useState } from "react";
import useSWRMutation from "swr/mutation";
import { Alert, AlertDescription, AlertTitle } from "~/components/ui/alert";
import { Button } from "~/components/ui/button";
import { DialogClose,  DialogFooter, DialogHeader } from "~/components/ui/dialog";
import { Input } from "~/components/ui/input";
import { Label } from "~/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "~/components/ui/select";
import { submitReservation } from "~/utils/fetcher/submit-reservation";
import { formatRupiah } from "~/utils/formatRupiah";

export const CreateReservationDialog = ({
  table_id,
  data,
}: {
  data: {
    pricePerHour: number;
  };
  table_id: string;
}) => {
  const [startTime, setStartTime] = useState(() =>
    dayjs().format("YYYY-MM-DDTHH:mm")
  );
  const [durationHours, setDurationHours] = useState<number>(1);
  const [customerName, setCustomerName] = useState("");

  const endTime = dayjs(startTime)
    .add(durationHours, "hour")
    .format("YYYY-MM-DDTHH:mm");

  const totalPrice = durationHours * data.pricePerHour;

  const { trigger, isMutating, error } = useSWRMutation(
    "/api/billiard_table/reservation",
    submitReservation
  );

  const handleSubmit = async () => {
    try {
      await trigger({
        customer_name: customerName,
        table_id,
        startTime,
        endTime,
        durationHours,
        totalPrice,
      });
      alert("Reservasi berhasil!");
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="outline">Buat Reservasi {table_id}</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Reservasi Meja</DialogTitle>
          <DialogDescription>
            Isi data reservasi dan klik simpan.
            
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4">
          <div className="grid gap-3">
            <Label htmlFor="customer_name">Customer Name</Label>
            <Input
              id="customer_name"
              name="name"
              placeholder="Nama pelanggan"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
            />
          </div>

          <div className="grid gap-5 md:grid-cols-1">
            {/* Start Time */}
            <div className="grid gap-3">
              <Label htmlFor="startTime">Start Time</Label>
              <Input
                id="startTime"
                name="startTime"
                type="datetime-local"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
              />
            </div>

            {/* Duration */}
            <div className="grid gap-3">
              <Label htmlFor="duration">Durasi (jam)</Label>
              <Select
                value={durationHours.toString()}
                onValueChange={(val) => setDurationHours(Number(val))}
              >
                <SelectTrigger className="w-full" id="duration">
                  <SelectValue placeholder="Pilih durasi" />
                </SelectTrigger>
                <SelectContent>
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((hour) => (
                    <SelectItem key={hour} value={hour.toString()}>
                      {hour} Jam
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* End Time (readonly) */}
            <div className="grid gap-3">
              <Label htmlFor="endTime">End Time</Label>
              <Input
                id="endTime"
                name="endTime"
                type="datetime-local"
                value={endTime}
                readOnly
              />
            </div>
          </div>

          <Alert>
            <BadgeInfo />
            <AlertTitle>Total Harga = {formatRupiah(totalPrice)}</AlertTitle>
            <AlertDescription>
              {formatRupiah(data.pricePerHour)} × {durationHours} Jam
            </AlertDescription>
          </Alert>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button variant="outline">Cancel</Button>
          </DialogClose>
          <Button onClick={handleSubmit} disabled={isMutating}>
            {isMutating ? "Menyimpan..." : "Reservasi Sekarang"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};