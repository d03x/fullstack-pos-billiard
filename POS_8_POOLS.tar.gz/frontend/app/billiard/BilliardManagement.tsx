import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "~/components/ui/dialog";
import {
  Clock,
  CheckCircle2,
  XCircle,
  Table2,
  Users,
  Info,
  Timer,
  Hourglass,
  RefreshCw,
  Plus,
  MessageSquare,
  Settings,
  CalendarX,
  LogOut,
} from "lucide-react";
import { Badge } from "~/components/ui/badge";
import { Button,  } from "~/components/ui/button";
import PageError from "~/components/PageError";
import PageLoading from "~/components/PageLoading";
import * as Card from "~/components/ui/card";
import { useGetDataTable } from "~/hook/useBilliardData";
import { cn } from "~/lib/utils";
import { Tooltip, TooltipContent, TooltipTrigger } from "~/components/ui/tooltip";
import { Progress } from "~/components/ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "~/components/ui/avatar";
import { Calendar } from "~/components/ui/calendar";
export default function BilliardManagement() {
  const { data, isLoading, error } = useGetDataTable();
  
  // Add this function for calculating session progress
  const calculateSessionProgress = (startTime: string, duration: string) => {
    // Implementation depends on your time format
    // This is just a placeholder example
    return Math.floor(Math.random() * 100);
  };

  if (isLoading) return <PageLoading />;
  if (error) return <PageError error={error} />;

  return (
    <div className="space-y-6">
      {/* Status Overview Cards */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
        <Card.Card className="bg-gradient-to-br from-green-50 to-green-100">
          <Card.CardHeader className="flex flex-row items-center justify-between pb-2">
            <Card.CardTitle className="text-sm font-medium text-green-800">
              Available Tables
            </Card.CardTitle>
            <CheckCircle2 className="h-5 w-5 text-green-600" />
          </Card.CardHeader>
          <Card.CardContent>
            <div className="text-2xl font-bold text-green-900">
              {data.filter((t: any) => t.status === "Available").length}
            </div>
            <p className="text-xs text-green-600">
              Ready for new sessions
            </p>
          </Card.CardContent>
        </Card.Card>

        <Card.Card className="bg-gradient-to-br from-amber-50 to-amber-100">
          <Card.CardHeader className="flex flex-row items-center justify-between pb-2">
            <Card.CardTitle className="text-sm font-medium text-amber-800">
              Reserved Tables
            </Card.CardTitle>
            <Hourglass className="h-5 w-5 text-amber-600" />
          </Card.CardHeader>
          <Card.CardContent>
            <div className="text-2xl font-bold text-amber-900">
              {data.filter((t: any) => t.status === "Reserved").length}
            </div>
            <p className="text-xs text-amber-600">
              Upcoming reservations
            </p>
          </Card.CardContent>
        </Card.Card>

        <Card.Card className="bg-gradient-to-br from-red-50 to-red-100">
          <Card.CardHeader className="flex flex-row items-center justify-between pb-2">
            <Card.CardTitle className="text-sm font-medium text-red-800">
              Occupied Tables
            </Card.CardTitle>
            <XCircle className="h-5 w-5 text-red-600" />
          </Card.CardHeader>
          <Card.CardContent>
            <div className="text-2xl font-bold text-red-900">
              {data.filter((t: any) => t.status === "Occupied").length}
            </div>
            <p className="text-xs text-red-600">
              Currently in use
            </p>
          </Card.CardContent>
        </Card.Card>
      </div>

      {/* Main Tables Grid */}
      <Card.Card className="border-0 shadow-sm">
        <Card.CardHeader className="pb-3">
          <div className="flex flex-col space-y-2 sm:flex-row sm:items-center sm:justify-between sm:space-y-0">
            <div>
              <Card.CardTitle className="text-2xl font-bold tracking-tight">
                Table Management
              </Card.CardTitle>
              <Card.CardDescription className="text-sm text-muted-foreground">
                Monitor and control all billiard tables
              </Card.CardDescription>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <RefreshCw className="mr-2 h-4 w-4" />
                Refresh
              </Button>
              <Button size="sm">
                <Plus className="mr-2 h-4 w-4" />
                Add Table
              </Button>
            </div>
          </div>
        </Card.CardHeader>
        
        <Card.CardContent>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
            {data.map((table: any) => {
              const isOccupied = table.status === "Occupied";
              const isReserved = table.status === "Reserved";
              const progress = isOccupied 
                ? calculateSessionProgress(table.startTime, table.duration) 
                : 0;

              return (
                <Dialog key={table.id}>
                  <DialogTrigger asChild>
                    <Card.Card
                      className={cn(
                        "group relative cursor-pointer overflow-hidden transition-all hover:shadow-md",
                        isOccupied
                          ? "border-red-100 bg-gradient-to-br from-red-50 to-white hover:border-red-200"
                          : isReserved
                          ? "border-amber-100 bg-gradient-to-br from-amber-50 to-white hover:border-amber-200"
                          : "border-green-100 bg-gradient-to-br from-green-50 to-white hover:border-green-200"
                      )}
                    >
                      {/* Status indicator bar */}
                      <div
                        className={cn(
                          "absolute left-0 top-0 h-full w-1",
                          isOccupied
                            ? "bg-gradient-to-b from-red-400 to-red-500"
                            : isReserved
                            ? "bg-gradient-to-b from-amber-400 to-amber-500"
                            : "bg-gradient-to-b from-green-400 to-green-500"
                        )}
                      />
                      
                      {/* Table number badge */}
                      <div className="absolute right-2 top-2">
                        <Badge
                          variant="secondary"
                          className={cn(
                            "px-2 py-1 text-xs font-mono",
                            isOccupied && "bg-red-100 text-red-800",
                            isReserved && "bg-amber-100 text-amber-800"
                          )}
                        >
                          #{table.number}
                        </Badge>
                      </div>

                      <Card.CardHeader className="pb-2">
                        <div className="flex items-start justify-between space-x-4">
                          <div>
                            <Card.CardTitle className="flex items-center text-lg font-semibold">
                              {table.name}
                              {isReserved && (
                                <Tooltip>
                                  <TooltipTrigger asChild>
                                    <Hourglass className="ml-2 h-4 w-4 text-amber-600" />
                                  </TooltipTrigger>
                                  <TooltipContent>
                                    <p>Reserved - starts in {table.timeUntilReservation}</p>
                                  </TooltipContent>
                                </Tooltip>
                              )}
                            </Card.CardTitle>
                            <Card.CardDescription className="text-sm">
                              {table.type || "Standard"}
                            </Card.CardDescription>
                          </div>
                          <div
                            className={cn(
                              "flex h-10 w-10 items-center justify-center rounded-full",
                              isOccupied
                                ? "bg-red-100 text-red-600"
                                : isReserved
                                ? "bg-amber-100 text-amber-600"
                                : "bg-green-100 text-green-600"
                            )}
                          >
                            {isOccupied ? (
                              <XCircle className="h-5 w-5" />
                            ) : isReserved ? (
                              <Timer className="h-5 w-5" />
                            ) : (
                              <CheckCircle2 className="h-5 w-5" />
                            )}
                          </div>
                        </div>
                      </Card.CardHeader>

                      <Card.CardContent className="pt-0">
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <Badge
                              variant={
                                isOccupied
                                  ? "destructive"
                                  : isReserved
                                  ? "warning"
                                  : "success"
                              }
                              className="px-2 py-1 text-xs"
                            >
                              {table.status}
                            </Badge>
                            {isOccupied && (
                              <div className="flex items-center text-sm text-muted-foreground">
                                <Clock className="mr-1 h-4 w-4" />
                                {table.duration || "1h 23m"}
                              </div>
                            )}
                          </div>

                          {isOccupied && (
                            <div className="space-y-2">
                              <Progress 
                                value={progress} 
                                className="h-2"
                                indicatorClassName={cn(
                                  "bg-red-500",
                                  progress > 80 && "bg-red-600",
                                  progress > 90 && "bg-red-700"
                                )}
                              />
                              <div className="flex items-center space-x-2">
                                <Avatar className="h-6 w-6">
                                  <AvatarImage src={table.customerAvatar} />
                                  <AvatarFallback>
                                    {table.customerName?.charAt(0) || "G"}
                                  </AvatarFallback>
                                </Avatar>
                                <span className="text-sm font-medium">
                                  {table.customerName || "Guest"}
                                </span>
                              </div>
                            </div>
                          )}

                          {isReserved && (
                            <div className="flex items-center space-x-2 text-sm text-amber-600">
                              <Calendar className="h-4 w-4" />
                              <span>
                                {table.reservationTime || "Soon"}
                              </span>
                            </div>
                          )}
                        </div>
                      </Card.CardContent>
                    </Card.Card>
                  </DialogTrigger>

                  {/* Enhanced Dialog Content */}
                  <DialogContent className="sm:max-w-[500px]">
                    <DialogHeader>
                      <div className="flex items-center space-x-3">
                        <div
                          className={cn(
                            "flex h-10 w-10 items-center justify-center rounded-full",
                            isOccupied
                              ? "bg-red-100 text-red-600"
                              : isReserved
                              ? "bg-amber-100 text-amber-600"
                              : "bg-green-100 text-green-600"
                          )}
                        >
                          {isOccupied ? (
                            <XCircle className="h-6 w-6" />
                          ) : isReserved ? (
                            <Timer className="h-6 w-6" />
                          ) : (
                            <CheckCircle2 className="h-6 w-6" />
                          )}
                        </div>
                        <div>
                          <DialogTitle>Table {table.name}</DialogTitle>
                          <DialogDescription>
                            {table.type || "Standard Billiard Table"}
                          </DialogDescription>
                        </div>
                      </div>
                    </DialogHeader>

                    <div className="grid gap-4 py-4">
                      {/* Table Status Card */}
                      <Card.Card className="border-0 bg-muted/50">
                        <Card.CardContent className="p-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1">
                              <p className="text-sm font-medium text-muted-foreground">
                                Current Status
                              </p>
                              <Badge
                                variant={
                                  isOccupied
                                    ? "destructive"
                                    : isReserved
                                    ? "warning"
                                    : "success"
                                }
                                className="text-sm"
                              >
                                {table.status}
                              </Badge>
                            </div>
                            <div className="space-y-1">
                              <p className="text-sm font-medium text-muted-foreground">
                                Hourly Rate
                              </p>
                              <p className="text-sm font-medium">
                                ${table.rate || "25.00"} / hour
                              </p>
                            </div>
                          </div>
                        </Card.CardContent>
                      </Card.Card>

                      {/* Session Details */}
                      {isOccupied && (
                        <>
                          <div className="space-y-2">
                            <h4 className="font-medium">Current Session</h4>
                            <div className="rounded-lg border p-4">
                              <div className="flex items-center space-x-3">
                                <Avatar>
                                  <AvatarImage src={table.customerAvatar} />
                                  <AvatarFallback>
                                    {table.customerName?.charAt(0) || "G"}
                                  </AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="font-medium">
                                    {table.customerName || "Guest"}
                                  </p>
                                  <p className="text-sm text-muted-foreground">
                                    {table.customerPhone || "No contact"}
                                  </p>
                                </div>
                              </div>
                              <div className="mt-4 grid grid-cols-3 gap-2">
                                <div className="space-y-1">
                                  <p className="text-xs text-muted-foreground">
                                    Start Time
                                  </p>
                                  <p className="text-sm font-medium">
                                    {table.startTime || "14:30"}
                                  </p>
                                </div>
                                <div className="space-y-1">
                                  <p className="text-xs text-muted-foreground">
                                    Duration
                                  </p>
                                  <p className="text-sm font-medium">
                                    {table.duration || "1h 23m"}
                                  </p>
                                </div>
                                <div className="space-y-1">
                                  <p className="text-xs text-muted-foreground">
                                    Amount Due
                                  </p>
                                  <p className="text-sm font-medium">
                                    ${table.amountDue || "35.50"}
                                  </p>
                                </div>
                              </div>
                              <Progress
                                value={progress}
                                className="mt-3 h-2"
                                indicatorClassName={cn(
                                  "bg-red-500",
                                  progress > 80 && "bg-red-600",
                                  progress > 90 && "bg-red-700"
                                )}
                              />
                            </div>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <Button variant="outline">
                              <MessageSquare className="mr-2 h-4 w-4" />
                              Message
                            </Button>
                            <Button variant="outline">
                              <Clock className="mr-2 h-4 w-4" />
                              Extend Time
                            </Button>
                          </div>
                        </>
                      )}

                      {/* Reservation Details */}
                      {isReserved && (
                        <div className="space-y-2">
                          <h4 className="font-medium">Reservation Details</h4>
                          <div className="rounded-lg border p-4">
                            <div className="flex items-center space-x-3">
                              <Avatar>
                                <AvatarImage src={table.reservedByAvatar} />
                                <AvatarFallback>
                                  {table.reservedByName?.charAt(0) || "R"}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <p className="font-medium">
                                  {table.reservedByName || "Reservation"}
                                </p>
                                <p className="text-sm text-muted-foreground">
                                  {table.reservedByPhone || "No contact"}
                                </p>
                              </div>
                            </div>
                            <div className="mt-4 grid grid-cols-2 gap-2">
                              <div className="space-y-1">
                                <p className="text-xs text-muted-foreground">
                                  Reserved For
                                </p>
                                <p className="text-sm font-medium">
                                  {table.reservationTime || "Today, 19:00"}
                                </p>
                              </div>
                              <div className="space-y-1">
                                <p className="text-xs text-muted-foreground">
                                  Duration
                                </p>
                                <p className="text-sm font-medium">
                                  {table.reservedDuration || "2 hours"}
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    <DialogFooter className="flex flex-col space-y-2 sm:flex-row sm:justify-between sm:space-x-0 sm:space-y-0">
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          History
                        </Button>
                        <Button variant="outline" size="sm">
                          <Settings className="mr-2 h-4 w-4" />
                          Settings
                        </Button>
                      </div>
                      <div className="flex space-x-2">
                        <DialogClose asChild>
                          <Button variant="outline" size="sm">
                            Close
                          </Button>
                        </DialogClose>
                        <Button
                          size="sm"
                          variant={isOccupied ? "destructive" : "default"}
                        >
                          {isOccupied ? (
                            <>
                              <LogOut className="mr-2 h-4 w-4" />
                              End Session
                            </>
                          ) : isReserved ? (
                            <>
                              <CalendarX className="mr-2 h-4 w-4" />
                              Cancel Reservation
                            </>
                          ) : (
                            <>
                              <Plus className="mr-2 h-4 w-4" />
                              New Session
                            </>
                          )}
                        </Button>
                      </div>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              );
            })}
          </div>
        </Card.CardContent>
      </Card.Card>
    </div>
  );
}